# Deploy to Vercel — step-by-step

Total time: ~10 minutes. No code editing required.

## 1. Push the code to GitHub

Easiest path if you don't want to use the command line: **GitHub Desktop**.

1. Install [GitHub Desktop](https://desktop.github.com/) and sign in.
2. File → Add Local Repository → pick the unzipped `legends-of-the-shattered-realm` folder.
3. It'll detect the existing commit on branch `claude/legends-vertical-slice`.
4. Repository → Repository Settings → Remote → set it to `https://github.com/kodeytomaka-gif/legends-of-the-shattered-realm.git`.
5. Click "Push origin".

Command-line alternative (in the unzipped folder):
```bash
git remote set-url origin https://github.com/kodeytomaka-gif/legends-of-the-shattered-realm.git
git push -u origin claude/legends-vertical-slice
```

## 2. Provision a Postgres database (free)

1. Go to [neon.tech](https://neon.tech) and sign in with GitHub.
2. Create a new project (default settings are fine).
3. Copy the **Pooled connection string** (it ends with `-pooler` in the host). You'll use this as `DATABASE_URL`.

## 3. Deploy on Vercel

1. Go to [vercel.com/new](https://vercel.com/new) and sign in with GitHub.
2. Click **Import** next to `legends-of-the-shattered-realm`.
3. Under **Environment Variables**, add:

| Name | Value |
|---|---|
| `DATABASE_URL` | The pooled Neon connection string from step 2 |
| `NEXTAUTH_SECRET` | A long random string. Generate one at https://generate-secret.vercel.app/32 |
| `NEXTAUTH_URL` | Leave blank for now — set it after first deploy to your `vercel.app` URL |
| `OPENAI_API_KEY` | Your key from https://platform.openai.com/api-keys |
| `AI_PROVIDER` | `openai` |
| `OPENAI_MODEL_NARRATION` | `gpt-4o-mini` |
| `OPENAI_MODEL_MAJOR` | `gpt-4o` |

4. Click **Deploy**. First deploy takes ~3 minutes.

## 4. Run the database migrations + seed (one-time)

After the first deploy succeeds, open a terminal on your machine in the unzipped project folder:

```bash
pnpm install
echo "DATABASE_URL=<paste the neon pooled string>" > .env
pnpm db:push
pnpm db:seed
```

This creates all the tables and seeds the 8 classes, 16 subclasses, 2 bosses, and items. You only ever do this once.

> Alternative if you can't run pnpm locally: in the Neon dashboard, use the SQL editor to run `prisma/migrations/...` after Vercel generates them — but `pnpm db:push` is far simpler.

## 5. Set NEXTAUTH_URL and redeploy

1. After step 3 finishes, copy your Vercel app URL (e.g. `https://legends-of-the-shattered-realm.vercel.app`).
2. Back in Vercel → Settings → Environment Variables, set `NEXTAUTH_URL` to that URL.
3. Deployments tab → click the latest one → "Redeploy".

## 6. Play

Open the Vercel URL, register, host a campaign, forge a character, and start playing.

---

## Notes & gotchas

- **Multiplayer realtime is disabled in the Vercel build** because Socket.IO needs a long-running server, which Vercel doesn't provide. Single-player and host-driven play work fully. To re-enable cross-client live sync, wire Pusher Channels (free tier) in `components/game/PlayClient.tsx` — the action POST already returns the DM update; you just need to fan it out.
- **If the build fails on Vercel** with a Prisma error: ensure `postinstall` ran (it should auto-run). If not, manually run `prisma generate` and recommit.
- **First DM response is slow** (~5-10s) because OpenAI takes time. Subsequent calls are similar. This is normal.
- **Cost**: Neon free tier covers small usage. Vercel free tier covers low traffic. OpenAI costs ~$0.001 per DM turn with `gpt-4o-mini` — a multi-hour campaign is pennies.

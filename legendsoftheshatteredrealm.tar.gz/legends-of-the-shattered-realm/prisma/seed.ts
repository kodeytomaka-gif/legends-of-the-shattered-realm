import { PrismaClient } from "@prisma/client";
import { CLASSES } from "../content/classes";
import { SUBCLASSES } from "../content/subclasses";
import { LOCATIONS } from "../content/locations";
import { QUESTS } from "../content/quests";
import { BOSSES } from "../content/bosses";
import { ITEMS } from "../content/items";

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding global content (classes, subclasses, bosses, items templates)...");

  for (const c of CLASSES) {
    await prisma.class.upsert({
      where: { id: c.id },
      create: {
        id: c.id,
        name: c.name,
        description: c.description,
        baseStats: c.baseStats,
        growthPath: c.growthPath,
        startingEquipment: c.startingEquipment,
        loreText: c.loreText,
      },
      update: {
        name: c.name,
        description: c.description,
        baseStats: c.baseStats,
        growthPath: c.growthPath,
        startingEquipment: c.startingEquipment,
        loreText: c.loreText,
      },
    });
  }

  for (const s of SUBCLASSES) {
    await prisma.subclass.upsert({
      where: { id: s.id },
      create: {
        id: s.id,
        classId: s.classId,
        name: s.name,
        description: s.description,
        abilities: s.abilities,
        passives: s.passives,
        ultimate: s.ultimate,
      },
      update: {
        classId: s.classId,
        name: s.name,
        description: s.description,
        abilities: s.abilities,
        passives: s.passives,
        ultimate: s.ultimate,
      },
    });
  }

  for (const b of BOSSES) {
    await prisma.boss.upsert({
      where: { id: b.id },
      create: {
        id: b.id,
        name: b.name,
        isMajor: b.isMajor,
        lore: b.lore,
        arena: b.arena,
        mechanics: b.mechanics,
        lootTable: b.lootTable,
        dialogue: b.dialogue,
      },
      update: {
        name: b.name,
        isMajor: b.isMajor,
        lore: b.lore,
        arena: b.arena,
        mechanics: b.mechanics,
        lootTable: b.lootTable,
        dialogue: b.dialogue,
      },
    });
  }

  for (const i of ITEMS) {
    const existing = await prisma.item.findFirst({
      where: { campaignId: null, externalId: i.externalId },
    });
    if (existing) {
      await prisma.item.update({
        where: { id: existing.id },
        data: {
          name: i.name,
          description: i.description,
          rarity: i.rarity,
          slot: i.slot ?? null,
          stats: i.stats ?? undefined,
          isUnique: i.isUnique ?? false,
        },
      });
    } else {
      await prisma.item.create({
        data: {
          externalId: i.externalId,
          name: i.name,
          description: i.description,
          rarity: i.rarity,
          slot: i.slot ?? null,
          stats: i.stats ?? undefined,
          isUnique: i.isUnique ?? false,
        },
      });
    }
  }

  console.log("Seed complete.");
  console.log(
    `  ${CLASSES.length} classes, ${SUBCLASSES.length} subclasses, ${BOSSES.length} bosses, ${ITEMS.length} items.`,
  );
  console.log(
    "Per-campaign content (locations, quests, npcs, factions) is seeded when a new campaign is created — see lib/campaign/create.ts.",
  );
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());

// Re-export so campaign-create can use without duplicating
export { LOCATIONS, QUESTS };

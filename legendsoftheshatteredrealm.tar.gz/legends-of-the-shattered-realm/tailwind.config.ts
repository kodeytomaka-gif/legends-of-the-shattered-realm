import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        parchment: {
          50: "#f8f1df",
          100: "#ede0bf",
          200: "#d8c597",
          300: "#b89e67",
          400: "#8c7240",
        },
        ink: {
          900: "#0c0a08",
          800: "#15110d",
          700: "#1f1813",
          600: "#2d231a",
        },
        gold: {
          400: "#e6c46a",
          500: "#d4af37",
          600: "#a8862a",
          700: "#7a6020",
        },
        ember: {
          500: "#c84b1e",
          600: "#a03515",
        },
        moss: {
          500: "#3a5b3a",
          600: "#2a4429",
        },
      },
      fontFamily: {
        display: ['"Cinzel"', "serif"],
        body: ['"Inter"', "system-ui", "sans-serif"],
      },
      boxShadow: {
        rune: "0 0 0 1px rgba(212,175,55,0.35), 0 0 24px rgba(212,175,55,0.15)",
      },
    },
  },
  plugins: [],
};

export default config;

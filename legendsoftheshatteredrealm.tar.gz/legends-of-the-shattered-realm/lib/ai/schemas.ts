import { z } from "zod";

export const ApproachEnum = z.enum([
  "combat",
  "stealth",
  "diplomacy",
  "creative",
]);

export const DmActionSchema = z.object({
  id: z.string(),
  type: ApproachEnum,
  label: z.string(),
  description: z.string(),
  risk: z.enum(["low", "medium", "high", "deadly"]),
  requirements: z.string(),
});

export const DmNpcSchema = z.object({
  name: z.string(),
  action: z.string(),
  dialogue: z.string(),
});

export const DmSceneSchema = z.object({
  location: z.string(),
  mood: z.string(),
  environment: z.string(),
});

export const DmStoryUpdateSchema = z.object({
  type: z.enum([
    "discovery",
    "relationship",
    "faction",
    "reputation",
    "world",
    "lore",
  ]),
  summary: z.string(),
});

export const DmQuestUpdateSchema = z.object({
  questId: z.string(),
  status: z.enum(["available", "active", "completed", "failed"]),
  summary: z.string(),
});

export const DmEnemySchema = z.object({
  name: z.string(),
  hp: z.number().int().nonnegative(),
  ac: z.number().int().nonnegative(),
  attack: z.string(),
  damage: z.string(),
  abilities: z.array(z.string()),
});

export const DmCombatSchema = z.object({
  startCombat: z.boolean(),
  enemies: z.array(DmEnemySchema),
});

export const DmRewardSchema = z.object({
  xp: z.number().int().nonnegative(),
  gold: z.number().int().nonnegative(),
  items: z.array(z.string()),
  reputation: z.array(
    z.object({ faction: z.string(), delta: z.number().int() }),
  ),
});

export const DmResponseSchema = z.object({
  narration: z.string(),
  scene: DmSceneSchema,
  npcs: z.array(DmNpcSchema),
  actions: z.array(DmActionSchema),
  storyUpdates: z.array(DmStoryUpdateSchema),
  questUpdates: z.array(DmQuestUpdateSchema),
  combat: DmCombatSchema,
  rewards: DmRewardSchema,
  hint: z.string(),
});

export type DmResponse = z.infer<typeof DmResponseSchema>;
export type DmAction = z.infer<typeof DmActionSchema>;
export type DmApproach = z.infer<typeof ApproachEnum>;

export const REQUIRED_APPROACHES: ReadonlyArray<DmApproach> = [
  "combat",
  "stealth",
  "diplomacy",
  "creative",
];

export function validateFourApproaches(actions: DmAction[]): {
  ok: boolean;
  missing: DmApproach[];
} {
  const seen = new Set(actions.map((a) => a.type));
  const missing = REQUIRED_APPROACHES.filter((t) => !seen.has(t));
  return { ok: missing.length === 0 && actions.length >= 4, missing };
}

import { prisma } from "@/lib/prisma";
import type { AiProvider } from "./adapter";
import { AiValidationError } from "./adapter";
import { getAiProvider } from "./providers";
import {
  DmResponse,
  DmResponseSchema,
  REQUIRED_APPROACHES,
  validateFourApproaches,
} from "./schemas";
import { DM_SYSTEM_PROMPT } from "./prompts/dm-system";
import { COMBAT_PROMPT_SUFFIX } from "./prompts/combat";
import { QUEST_PROMPT_SUFFIX } from "./prompts/quest";
import { ENCOUNTER_PROMPT_SUFFIX } from "./prompts/encounter";
import { buildContextMessages } from "./prompts/context";

export type SceneKind = "exploration" | "combat" | "quest" | "encounter";

export interface DmTurnRequest {
  campaignId: string;
  playerActionText: string;
  chosenActionId?: string;
  sceneKind?: SceneKind;
}

export interface DmTurnResult {
  response: DmResponse;
  storyEventId: string;
  aiTurnId: string;
}

const FALLBACK: DmResponse = {
  narration:
    "A chill wind threads through the realm; the storyteller pauses to gather their breath. The path before you remains, dim but waiting.",
  scene: {
    location: "an uncertain crossing",
    mood: "tense and quiet",
    environment: "still air, a thin grey light",
  },
  npcs: [],
  actions: [
    {
      id: "fallback-combat",
      type: "combat",
      label: "Ready your weapon",
      description: "Brace for whatever comes.",
      risk: "low",
      requirements: "none",
    },
    {
      id: "fallback-stealth",
      type: "stealth",
      label: "Move quietly",
      description: "Slip into cover and listen.",
      risk: "low",
      requirements: "none",
    },
    {
      id: "fallback-diplomacy",
      type: "diplomacy",
      label: "Call out",
      description: "Announce yourselves and listen for a reply.",
      risk: "low",
      requirements: "none",
    },
    {
      id: "fallback-creative",
      type: "creative",
      label: "Cast Light",
      description: "Conjure a small flame and survey the way forward.",
      risk: "low",
      requirements: "any caster",
    },
  ],
  storyUpdates: [],
  questUpdates: [],
  combat: { startCombat: false, enemies: [] },
  rewards: { xp: 0, gold: 0, items: [], reputation: [] },
  hint: "The narrative hesitated. Try again or simplify your action.",
};

function buildSystemPrompt(kind: SceneKind | undefined): string {
  const parts = [DM_SYSTEM_PROMPT];
  if (kind === "combat") parts.push("\n" + COMBAT_PROMPT_SUFFIX);
  if (kind === "quest") parts.push("\n" + QUEST_PROMPT_SUFFIX);
  if (kind === "encounter") parts.push("\n" + ENCOUNTER_PROMPT_SUFFIX);
  return parts.join("\n");
}

export async function runDmTurn(
  req: DmTurnRequest,
  providerOverride?: AiProvider,
): Promise<DmTurnResult> {
  const provider = providerOverride ?? getAiProvider();

  const campaign = await prisma.campaign.findUnique({
    where: { id: req.campaignId },
    include: {
      players: {
        include: {
          character: { include: { class: true, subclass: true } },
        },
      },
      npcs: true,
      factions: true,
    },
  });
  if (!campaign) throw new Error(`Campaign not found: ${req.campaignId}`);

  const location = campaign.currentLocationId
    ? await prisma.location.findUnique({
        where: { id: campaign.currentLocationId },
      })
    : null;

  const [activeQuests, recentEvents, memories] = await Promise.all([
    prisma.quest.findMany({
      where: { campaignId: campaign.id, status: { in: ["ACTIVE", "AVAILABLE"] } },
      include: { location: true },
    }),
    prisma.storyEvent.findMany({
      where: { campaignId: campaign.id },
      orderBy: { createdAt: "desc" },
      take: 12,
    }),
    prisma.aiMemory.findMany({
      where: { campaignId: campaign.id },
      orderBy: [{ weight: "desc" }, { createdAt: "desc" }],
      take: 20,
    }),
  ]);

  const party = campaign.players
    .filter((p): p is typeof p & { character: NonNullable<typeof p.character> } => !!p.character)
    .map((p) => ({
      character: p.character,
      playerName: p.displayName,
    }));

  const userMessage = buildContextMessages({
    location,
    party,
    activeQuests,
    recentEvents: [...recentEvents].reverse(),
    memories,
    npcs: campaign.npcs,
    factions: campaign.factions,
    storySummary: campaign.storySummary,
    playerActionText: req.playerActionText,
    chosenActionId: req.chosenActionId,
  });

  const systemPrompt = buildSystemPrompt(req.sceneKind);

  let completion;
  try {
    completion = await provider.complete({
      systemPrompt,
      messages: [{ role: "user", content: userMessage }],
      schema: DmResponseSchema,
      schemaName: "DmResponse",
    });
  } catch (err) {
    if (err instanceof AiValidationError) {
      // one retry with stricter directive
      completion = await provider.complete({
        systemPrompt:
          systemPrompt +
          `\n\nThe previous response was invalid: ${err.message}. Return ONLY a JSON object exactly matching the schema. Provide all four approach types: ${REQUIRED_APPROACHES.join(", ")}.`,
        messages: [{ role: "user", content: userMessage }],
        schema: DmResponseSchema,
        schemaName: "DmResponse",
      });
    } else {
      throw err;
    }
  }

  let response = completion.data;
  const approachCheck = validateFourApproaches(response.actions);
  if (!approachCheck.ok) {
    // Best-effort fix: pad with neutral options for any missing approaches.
    const additions = approachCheck.missing.map((type) => ({
      id: `auto-${type}`,
      type,
      label: `Consider a ${type} approach`,
      description: `Take a ${type} angle on the situation.`,
      risk: "medium" as const,
      requirements: "none",
    }));
    response = { ...response, actions: [...response.actions, ...additions] };
  }

  const result = await prisma.$transaction(async (tx) => {
    const aiTurn = await tx.aiTurn.create({
      data: {
        campaignId: campaign.id,
        model: completion.model,
        request: { systemPrompt, messages: [{ role: "user", content: userMessage }] },
        response: response as object,
        tokensIn: completion.tokensIn,
        tokensOut: completion.tokensOut,
        durationMs: completion.durationMs,
      },
    });

    const storyEvent = await tx.storyEvent.create({
      data: {
        campaignId: campaign.id,
        type: req.sceneKind ?? "narration",
        summary: response.narration.slice(0, 500),
        payload: response as object,
      },
    });

    if (req.playerActionText) {
      await tx.chatMessage.create({
        data: {
          campaignId: campaign.id,
          role: "PLAYER",
          content: req.playerActionText,
        },
      });
    }

    await tx.chatMessage.create({
      data: {
        campaignId: campaign.id,
        role: "DM",
        content: response.narration,
        payload: response as object,
      },
    });

    for (const update of response.storyUpdates) {
      await tx.aiMemory.create({
        data: {
          campaignId: campaign.id,
          category: update.type,
          key: update.summary.slice(0, 60),
          value: update.summary,
          weight: update.type === "world" || update.type === "faction" ? 3 : 1,
        },
      });
    }

    for (const qu of response.questUpdates) {
      const existing = await tx.quest.findFirst({
        where: { campaignId: campaign.id, OR: [{ id: qu.questId }, { externalId: qu.questId }] },
      });
      if (existing) {
        await tx.quest.update({
          where: { id: existing.id },
          data: {
            status: qu.status.toUpperCase() as "AVAILABLE" | "ACTIVE" | "COMPLETED" | "FAILED",
            outcomeSummary: qu.summary,
          },
        });
      }
    }

    if (response.rewards.xp > 0 || response.rewards.gold > 0) {
      for (const p of campaign.players) {
        if (!p.character) continue;
        const status = (p.character.status as { gold?: number; effects?: unknown[] }) ?? {};
        const nextStatus: Record<string, unknown> = {
          ...status,
          gold:
            (status.gold ?? 0) +
            Math.floor(response.rewards.gold / Math.max(1, party.length)),
        };
        await tx.character.update({
          where: { id: p.character.id },
          data: {
            xp: { increment: Math.floor(response.rewards.xp / Math.max(1, party.length)) },
            status: nextStatus as object,
          },
        });
      }
    }

    return { aiTurnId: aiTurn.id, storyEventId: storyEvent.id };
  });

  return { response, ...result };
}

export const __test__ = {
  FALLBACK,
  buildSystemPrompt,
};

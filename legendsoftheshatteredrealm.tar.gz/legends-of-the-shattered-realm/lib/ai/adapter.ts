import type { z } from "zod";

export interface AiMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface AiCompleteOptions<TSchema extends z.ZodTypeAny> {
  systemPrompt: string;
  messages: AiMessage[];
  schema: TSchema;
  schemaName: string;
  model?: string;
  temperature?: number;
  maxTokens?: number;
}

export interface AiCompletion<TOut> {
  data: TOut;
  raw: string;
  model: string;
  tokensIn: number;
  tokensOut: number;
  durationMs: number;
}

export interface AiProvider {
  readonly id: string;
  complete<TSchema extends z.ZodTypeAny>(
    opts: AiCompleteOptions<TSchema>,
  ): Promise<AiCompletion<z.infer<TSchema>>>;
}

export class AiValidationError extends Error {
  constructor(
    message: string,
    public readonly raw: string,
    public readonly issues: unknown,
  ) {
    super(message);
    this.name = "AiValidationError";
  }
}

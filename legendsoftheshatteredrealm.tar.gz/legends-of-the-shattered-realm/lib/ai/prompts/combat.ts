export const COMBAT_PROMPT_SUFFIX = `Active combat is underway. When narrating, focus on:
- The current turn's actions and their tactile, sensory impact.
- The position of enemies, allies, and the environment.
- Status effects, momentum shifts, and hard choices.
Do NOT add new enemies mid-fight unless the scene demands reinforcements. The 4 actions you provide should map to: a martial strike, a stealthy/positioning move, a parley/intimidate gambit, and a creative/spellcraft option.`;

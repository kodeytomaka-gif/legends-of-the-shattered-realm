import type { Character, Class, Subclass, Location, Quest, StoryEvent, AiMemory, NPC, Faction } from "@prisma/client";

interface PartyMember {
  character: Character & { class: Class; subclass: Subclass | null };
  playerName: string;
}

interface ContextInput {
  location: Location | null;
  party: PartyMember[];
  activeQuests: (Quest & { location: Location | null })[];
  recentEvents: StoryEvent[];
  memories: AiMemory[];
  npcs: NPC[];
  factions: Faction[];
  storySummary: string | null;
  playerActionText: string;
  chosenActionId?: string;
}

export function buildContextMessages(input: ContextInput): string {
  const lines: string[] = [];

  lines.push("=== WORLD ===");
  if (input.location) {
    lines.push(`Current Location: ${input.location.name} (${input.location.type})`);
    if (input.location.description) lines.push(`Description: ${input.location.description}`);
    if (input.location.lore) lines.push(`Lore: ${input.location.lore}`);
  } else {
    lines.push("Current Location: unknown (campaign opening)");
  }

  lines.push("");
  lines.push("=== PARTY ===");
  for (const p of input.party) {
    const c = p.character;
    const stats = c.stats as Record<string, number>;
    const statStr = ["str", "dex", "con", "int", "wis", "cha"]
      .map((k) => `${k.toUpperCase()} ${stats[k] ?? 10}`)
      .join(" ");
    lines.push(
      `- ${c.name} (${p.playerName}) — ${c.class.name}${
        c.subclass ? "/" + c.subclass.name : ""
      } L${c.level} — HP ${c.hp}/${c.maxHp} — ${statStr}`,
    );
  }

  lines.push("");
  lines.push("=== ACTIVE QUESTS ===");
  if (input.activeQuests.length === 0) {
    lines.push("(none yet)");
  } else {
    for (const q of input.activeQuests) {
      lines.push(`- [${q.status}] ${q.title}${q.location ? " @ " + q.location.name : ""}`);
      if (q.description) lines.push(`  ${q.description}`);
    }
  }

  if (input.npcs.length > 0) {
    lines.push("");
    lines.push("=== KNOWN NPCS ===");
    for (const n of input.npcs.slice(0, 12)) {
      lines.push(`- ${n.name}${n.faction ? " (" + n.faction + ")" : ""}: ${n.description}`);
    }
  }

  if (input.factions.length > 0) {
    lines.push("");
    lines.push("=== FACTIONS & REPUTATION ===");
    for (const f of input.factions) {
      lines.push(`- ${f.name}: reputation ${f.reputation} — ${f.description}`);
    }
  }

  if (input.storySummary) {
    lines.push("");
    lines.push("=== STORY SO FAR ===");
    lines.push(input.storySummary);
  }

  if (input.memories.length > 0) {
    lines.push("");
    lines.push("=== CAMPAIGN MEMORY (canon — must not contradict) ===");
    for (const m of input.memories) {
      lines.push(`- [${m.category}] ${m.key}: ${m.value}`);
    }
  }

  if (input.recentEvents.length > 0) {
    lines.push("");
    lines.push("=== RECENT EVENTS ===");
    for (const e of input.recentEvents.slice(-12)) {
      lines.push(`- [${e.type}] ${e.summary}`);
    }
  }

  lines.push("");
  lines.push("=== PLAYER ACTION ===");
  if (input.chosenActionId) {
    lines.push(`Chose option: ${input.chosenActionId}`);
  }
  lines.push(input.playerActionText);

  lines.push("");
  lines.push(
    "Resolve the action. Apply consequences. Return JSON matching the DmResponse schema. Provide exactly 4 actions (combat, stealth, diplomacy, creative). Do not break character.",
  );
  return lines.join("\n");
}

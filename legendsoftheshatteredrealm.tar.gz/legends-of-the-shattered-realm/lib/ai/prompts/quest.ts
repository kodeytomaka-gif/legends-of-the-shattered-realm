export const QUEST_PROMPT_SUFFIX = `The party is engaging with quest content. Make the four approaches genuinely distinct in tone, risk, and outcome:
- combat: direct, violent, decisive. Good if the party is strong; risky if they're hurt.
- stealth: indirect, clever, exposure-risk. Good for low-level or wounded parties.
- diplomacy: social, persuasive, manipulative. Opens unique outcomes that close violent doors.
- creative: magical, environmental, or unorthodox. Highest variance — biggest payoff, biggest risk.`;

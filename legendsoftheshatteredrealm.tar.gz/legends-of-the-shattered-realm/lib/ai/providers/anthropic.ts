import type { z } from "zod";
import type {
  AiCompleteOptions,
  AiCompletion,
  AiProvider,
} from "../adapter";

export class AnthropicProvider implements AiProvider {
  readonly id = "anthropic";
  async complete<TSchema extends z.ZodTypeAny>(
    _opts: AiCompleteOptions<TSchema>,
  ): Promise<AiCompletion<z.infer<TSchema>>> {
    throw new Error(
      "AnthropicProvider is a stub. Implement using @anthropic-ai/sdk + tool-use schema before enabling.",
    );
  }
}

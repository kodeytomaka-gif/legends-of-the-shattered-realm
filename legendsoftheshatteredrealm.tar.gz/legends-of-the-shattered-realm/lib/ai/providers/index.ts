import type { AiProvider } from "../adapter";
import { OpenAiProvider } from "./openai";
import { AnthropicProvider } from "./anthropic";
import { LocalLlmProvider } from "./local";

let cached: AiProvider | null = null;

export function getAiProvider(): AiProvider {
  if (cached) return cached;
  const id = (process.env.AI_PROVIDER ?? "openai").toLowerCase();
  switch (id) {
    case "openai":
      cached = new OpenAiProvider();
      break;
    case "anthropic":
      cached = new AnthropicProvider();
      break;
    case "local":
      cached = new LocalLlmProvider();
      break;
    default:
      throw new Error(`Unknown AI_PROVIDER: ${id}`);
  }
  return cached;
}

export function resetAiProviderCache(): void {
  cached = null;
}

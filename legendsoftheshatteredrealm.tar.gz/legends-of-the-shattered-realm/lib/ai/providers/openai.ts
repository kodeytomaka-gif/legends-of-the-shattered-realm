import OpenAI from "openai";
import type { z } from "zod";
import {
  AiCompleteOptions,
  AiCompletion,
  AiProvider,
  AiValidationError,
} from "../adapter";

let client: OpenAI | null = null;
function getClient(): OpenAI {
  if (!client) {
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) throw new Error("OPENAI_API_KEY is not set");
    client = new OpenAI({ apiKey });
  }
  return client;
}

function zodToJsonSchema(schema: z.ZodTypeAny): Record<string, unknown> {
  // Minimal Zod → JSON Schema converter sufficient for DM schemas.
  // Avoids pulling a heavy dependency for the MVP.
  const def = (schema as unknown as { _def: { typeName: string } })._def;
  const tn = def.typeName;
  switch (tn) {
    case "ZodString":
      return { type: "string" };
    case "ZodNumber":
      return { type: "number" };
    case "ZodBoolean":
      return { type: "boolean" };
    case "ZodNull":
      return { type: "null" };
    case "ZodLiteral": {
      const value = (def as unknown as { value: unknown }).value;
      return { const: value };
    }
    case "ZodEnum": {
      const values = (def as unknown as { values: string[] }).values;
      return { type: "string", enum: values };
    }
    case "ZodArray": {
      const inner = (def as unknown as { type: z.ZodTypeAny }).type;
      return { type: "array", items: zodToJsonSchema(inner) };
    }
    case "ZodOptional":
    case "ZodNullable": {
      const inner = (def as unknown as { innerType: z.ZodTypeAny }).innerType;
      return zodToJsonSchema(inner);
    }
    case "ZodObject": {
      const shape = (
        schema as unknown as { shape: Record<string, z.ZodTypeAny> }
      ).shape;
      const properties: Record<string, unknown> = {};
      const required: string[] = [];
      for (const [key, value] of Object.entries(shape)) {
        properties[key] = zodToJsonSchema(value);
        const vDef = (value as unknown as { _def: { typeName: string } })._def;
        if (vDef.typeName !== "ZodOptional" && vDef.typeName !== "ZodDefault") {
          required.push(key);
        }
      }
      return {
        type: "object",
        properties,
        required,
        additionalProperties: false,
      };
    }
    case "ZodUnion": {
      const options = (def as unknown as { options: z.ZodTypeAny[] }).options;
      return { anyOf: options.map(zodToJsonSchema) };
    }
    case "ZodDefault": {
      const inner = (def as unknown as { innerType: z.ZodTypeAny }).innerType;
      return zodToJsonSchema(inner);
    }
    default:
      return {};
  }
}

export class OpenAiProvider implements AiProvider {
  readonly id = "openai";

  async complete<TSchema extends z.ZodTypeAny>(
    opts: AiCompleteOptions<TSchema>,
  ): Promise<AiCompletion<z.infer<TSchema>>> {
    const model =
      opts.model ?? process.env.OPENAI_MODEL_NARRATION ?? "gpt-4o-mini";
    const jsonSchema = zodToJsonSchema(opts.schema);
    const started = Date.now();
    const completion = await getClient().chat.completions.create({
      model,
      temperature: opts.temperature ?? 0.85,
      max_tokens: opts.maxTokens ?? 1400,
      response_format: {
        type: "json_schema",
        json_schema: {
          name: opts.schemaName,
          schema: jsonSchema as Record<string, unknown>,
          strict: true,
        },
      },
      messages: [
        { role: "system", content: opts.systemPrompt },
        ...opts.messages.map((m) => ({ role: m.role, content: m.content })),
      ],
    });

    const raw = completion.choices[0]?.message?.content ?? "";
    let parsed: unknown;
    try {
      parsed = JSON.parse(raw);
    } catch (err) {
      throw new AiValidationError("OpenAI returned non-JSON", raw, err);
    }
    const result = opts.schema.safeParse(parsed);
    if (!result.success) {
      throw new AiValidationError(
        "OpenAI response failed schema validation",
        raw,
        result.error.issues,
      );
    }
    return {
      data: result.data,
      raw,
      model,
      tokensIn: completion.usage?.prompt_tokens ?? 0,
      tokensOut: completion.usage?.completion_tokens ?? 0,
      durationMs: Date.now() - started,
    };
  }
}

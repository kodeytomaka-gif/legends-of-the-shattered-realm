import type { z } from "zod";
import type {
  AiCompleteOptions,
  AiCompletion,
  AiProvider,
} from "../adapter";

export class LocalLlmProvider implements AiProvider {
  readonly id = "local";
  async complete<TSchema extends z.ZodTypeAny>(
    _opts: AiCompleteOptions<TSchema>,
  ): Promise<AiCompletion<z.infer<TSchema>>> {
    throw new Error(
      "LocalLlmProvider is a stub. Point at an OpenAI-compatible local endpoint (e.g. Ollama) before enabling.",
    );
  }
}

import { prisma } from "@/lib/prisma";
import { generateInviteCode } from "@/lib/utils";
import { LOCATIONS } from "@/content/locations";
import { QUESTS } from "@/content/quests";
import { NPCS } from "@/content/npcs";
import { FACTIONS } from "@/content/factions";
import { MAIN_CAMPAIGN } from "@/content/campaigns/main";
import type { CampaignMode } from "@prisma/client";

export interface CreateCampaignInput {
  name: string;
  description?: string;
  hostUserId?: string;
  hostDisplayName: string;
  mode: CampaignMode;
}

export async function createCampaign(input: CreateCampaignInput) {
  const inviteCode = generateInviteCode();

  return prisma.$transaction(async (tx) => {
    const campaign = await tx.campaign.create({
      data: {
        name: input.name,
        description: input.description,
        hostId: input.hostUserId ?? "local-host",
        mode: input.mode,
        inviteCode,
        storySummary: MAIN_CAMPAIGN.pitch,
        seed: Math.floor(Math.random() * 2_147_483_647),
      },
    });

    // Host player
    await tx.player.create({
      data: {
        campaignId: campaign.id,
        userId: input.hostUserId ?? null,
        isLocal: !input.hostUserId,
        displayName: input.hostDisplayName,
        isHost: true,
      },
    });

    // Locations
    const locByExt: Record<string, string> = {};
    for (const l of LOCATIONS) {
      const created = await tx.location.create({
        data: {
          campaignId: campaign.id,
          externalId: l.externalId,
          name: l.name,
          type: l.type,
          description: l.description,
          lore: l.lore,
          discovered: !!l.startingLocation,
          payload: (l.payload ?? undefined) as object | undefined,
        },
      });
      locByExt[l.externalId] = created.id;
      if (l.startingLocation) {
        await tx.campaign.update({
          where: { id: campaign.id },
          data: { currentLocationId: created.id },
        });
      }
    }

    // Quests
    for (const q of QUESTS) {
      await tx.quest.create({
        data: {
          campaignId: campaign.id,
          externalId: q.externalId,
          locationId: locByExt[q.locationExternalId],
          title: q.title,
          description: q.description,
          status: "AVAILABLE",
          options: q.options as unknown as object,
        },
      });
    }

    // NPCs
    for (const n of NPCS) {
      await tx.nPC.create({
        data: {
          campaignId: campaign.id,
          externalId: n.externalId,
          name: n.name,
          description: n.description,
          faction: n.faction,
          locationRef: n.locationExternalId,
          relationship: {},
          dialogueHints: n.dialogueHints,
        },
      });
    }

    // Factions
    for (const f of FACTIONS) {
      await tx.faction.create({
        data: {
          campaignId: campaign.id,
          externalId: f.externalId,
          name: f.name,
          description: f.description,
          reputation: 0,
        },
      });
    }

    // Memory seeds from the main campaign
    for (const m of MAIN_CAMPAIGN.memorySeeds) {
      await tx.aiMemory.create({
        data: {
          campaignId: campaign.id,
          category: m.category,
          key: m.key,
          value: m.value,
          weight: m.weight,
        },
      });
    }

    await tx.storyEvent.create({
      data: {
        campaignId: campaign.id,
        type: "campaign_start",
        summary: `Campaign "${input.name}" begins in ${input.mode.toLowerCase()} mode.`,
      },
    });

    return campaign;
  });
}

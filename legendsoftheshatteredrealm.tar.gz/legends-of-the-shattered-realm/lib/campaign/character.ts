import { prisma } from "@/lib/prisma";

export interface CreateCharacterInput {
  playerId: string;
  name: string;
  classId: string;
  subclassId?: string;
}

export async function createCharacter(input: CreateCharacterInput) {
  const classDef = await prisma.class.findUnique({ where: { id: input.classId } });
  if (!classDef) throw new Error(`Unknown class: ${input.classId}`);
  const baseStats = classDef.baseStats as { str: number; dex: number; con: number; int: number; wis: number; cha: number };
  const growth = classDef.growthPath as { hpPerLevel: number; abilitiesByLevel: Record<string, string[]> };
  const startingHp = 10 + Math.floor((baseStats.con - 10) / 2) + growth.hpPerLevel;
  const startAbilities = growth.abilitiesByLevel["1"] ?? [];

  return prisma.character.create({
    data: {
      playerId: input.playerId,
      name: input.name,
      classId: input.classId,
      subclassId: input.subclassId,
      level: 1,
      xp: 0,
      hp: startingHp,
      maxHp: startingHp,
      stats: baseStats,
      equipment: Object.fromEntries(
        (classDef.startingEquipment as string[]).map((id, i) => [`slot${i}`, id]),
      ),
      inventory: [{ itemId: "healing-draught", qty: 2 }],
      abilities: startAbilities,
      status: { effects: [], gold: 25 },
    },
  });
}

export const XP_TABLE: ReadonlyArray<number> = [
  0,      // L1
  300,    // L2
  900,    // L3
  2700,   // L4
  6500,   // L5
  14000,  // L6
  23000,  // L7
  34000,  // L8
  48000,  // L9
  64000,  // L10
];

export function levelForXp(xp: number): number {
  let lvl = 1;
  for (let i = 0; i < XP_TABLE.length; i++) {
    if (xp >= XP_TABLE[i]) lvl = i + 1;
  }
  return lvl;
}

export function xpToNext(xp: number): { current: number; next: number; needed: number } {
  const lvl = levelForXp(xp);
  const current = XP_TABLE[lvl - 1];
  const next = XP_TABLE[lvl] ?? XP_TABLE[XP_TABLE.length - 1] + 16000;
  return { current, next, needed: Math.max(0, next - xp) };
}

export interface LevelUpResult {
  oldLevel: number;
  newLevel: number;
  leveledUp: boolean;
  hpGain: number;
  newAbilities: string[];
}

export function applyLevelUp(
  xp: number,
  currentLevel: number,
  conScore: number,
  growthPath: { abilitiesByLevel?: Record<string, string[]> } | null | undefined,
): LevelUpResult {
  const newLevel = levelForXp(xp);
  if (newLevel <= currentLevel) {
    return {
      oldLevel: currentLevel,
      newLevel: currentLevel,
      leveledUp: false,
      hpGain: 0,
      newAbilities: [],
    };
  }
  const conMod = Math.floor((conScore - 10) / 2);
  const hpGain = (newLevel - currentLevel) * (5 + Math.max(0, conMod));
  const newAbilities: string[] = [];
  if (growthPath?.abilitiesByLevel) {
    for (let l = currentLevel + 1; l <= newLevel; l++) {
      const arr = growthPath.abilitiesByLevel[String(l)];
      if (arr) newAbilities.push(...arr);
    }
  }
  return { oldLevel: currentLevel, newLevel, leveledUp: true, hpGain, newAbilities };
}

import { prisma } from "@/lib/prisma";

export async function discoverLocation(campaignId: string, externalId: string) {
  return prisma.location.updateMany({
    where: { campaignId, externalId },
    data: { discovered: true },
  });
}

export async function setCurrentLocation(campaignId: string, locationId: string) {
  return prisma.campaign.update({
    where: { id: campaignId },
    data: { currentLocationId: locationId },
  });
}

export async function listDiscoveredLocations(campaignId: string) {
  return prisma.location.findMany({
    where: { campaignId, discovered: true },
    orderBy: { name: "asc" },
  });
}

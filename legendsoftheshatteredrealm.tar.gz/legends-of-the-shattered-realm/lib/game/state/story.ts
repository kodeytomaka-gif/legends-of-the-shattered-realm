import { prisma } from "@/lib/prisma";

export async function appendStoryEvent(
  campaignId: string,
  type: string,
  summary: string,
  payload?: Record<string, unknown>,
) {
  return prisma.storyEvent.create({
    data: {
      campaignId,
      type,
      summary,
      payload: (payload ?? undefined) as object | undefined,
    },
  });
}

export async function recentStorySummary(campaignId: string, take = 10): Promise<string> {
  const events = await prisma.storyEvent.findMany({
    where: { campaignId },
    orderBy: { createdAt: "desc" },
    take,
  });
  return events.reverse().map((e) => `• ${e.summary}`).join("\n");
}

import { prisma } from "@/lib/prisma";
import type { QuestStatus } from "@prisma/client";

export async function setQuestStatus(questId: string, status: QuestStatus, summary?: string) {
  return prisma.quest.update({
    where: { id: questId },
    data: { status, outcomeSummary: summary ?? undefined },
  });
}

export async function listCampaignQuests(campaignId: string) {
  return prisma.quest.findMany({
    where: { campaignId },
    include: { location: true },
    orderBy: { status: "asc" },
  });
}

import { prisma } from "@/lib/prisma";
import type { CombatState } from "../combat-engine";

export async function persistCombatState(campaignId: string, state: CombatState) {
  return prisma.encounter.upsert({
    where: { id: state.id },
    create: {
      id: state.id,
      campaignId,
      type: "combat",
      status: state.finished ? "completed" : "active",
      payload: state as unknown as object,
    },
    update: {
      status: state.finished ? "completed" : "active",
      payload: state as unknown as object,
    },
  });
}

export async function loadCombatState(encounterId: string): Promise<CombatState | null> {
  const enc = await prisma.encounter.findUnique({ where: { id: encounterId } });
  if (!enc) return null;
  return enc.payload as unknown as CombatState;
}

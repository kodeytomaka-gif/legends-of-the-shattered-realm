import { prisma } from "@/lib/prisma";
import { applyLevelUp, levelForXp } from "../progression";

export async function awardXp(characterId: string, xp: number) {
  const character = await prisma.character.findUnique({
    where: { id: characterId },
    include: { class: true },
  });
  if (!character) throw new Error("Character not found");
  const newXp = character.xp + xp;
  const stats = character.stats as Record<string, number>;
  const result = applyLevelUp(
    newXp,
    character.level,
    stats.con ?? 10,
    character.class.growthPath as { abilitiesByLevel?: Record<string, string[]> },
  );
  const newLevel = result.leveledUp ? result.newLevel : levelForXp(newXp);
  const newAbilities = result.leveledUp
    ? [...(character.abilities as string[]), ...result.newAbilities]
    : (character.abilities as string[]);
  return prisma.character.update({
    where: { id: characterId },
    data: {
      xp: newXp,
      level: newLevel,
      maxHp: character.maxHp + result.hpGain,
      hp: Math.min(character.maxHp + result.hpGain, character.hp + result.hpGain),
      abilities: newAbilities,
    },
  });
}

export async function applyDamage(characterId: string, amount: number) {
  const c = await prisma.character.findUnique({ where: { id: characterId } });
  if (!c) throw new Error("Character not found");
  const hp = Math.max(0, c.hp - amount);
  return prisma.character.update({ where: { id: characterId }, data: { hp } });
}

export async function applyHealing(characterId: string, amount: number) {
  const c = await prisma.character.findUnique({ where: { id: characterId } });
  if (!c) throw new Error("Character not found");
  const hp = Math.min(c.maxHp, c.hp + amount);
  return prisma.character.update({ where: { id: characterId }, data: { hp } });
}

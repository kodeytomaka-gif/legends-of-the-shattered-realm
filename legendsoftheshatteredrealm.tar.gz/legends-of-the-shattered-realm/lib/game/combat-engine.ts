import { rollDice, abilityMod } from "./dice";

export interface Combatant {
  id: string;
  name: string;
  side: "party" | "enemy";
  hp: number;
  maxHp: number;
  ac: number;
  initiative: number;
  stats: { str: number; dex: number; con: number; int: number; wis: number; cha: number };
  statusEffects: StatusEffect[];
  isDown: boolean;
}

export interface StatusEffect {
  id: string;
  name: string;
  duration: number;
  payload?: Record<string, number | string>;
}

export interface CombatState {
  id: string;
  round: number;
  turnIdx: number;
  order: string[]; // combatant ids
  combatants: Record<string, Combatant>;
  log: CombatLogEntry[];
  finished: boolean;
  winner?: "party" | "enemy";
}

export interface CombatLogEntry {
  round: number;
  actorId: string;
  text: string;
}

export function startCombat(
  party: Omit<Combatant, "initiative" | "statusEffects" | "isDown" | "side">[],
  enemies: Omit<Combatant, "initiative" | "statusEffects" | "isDown" | "side">[],
  rng: () => number = Math.random,
): CombatState {
  const combatants: Record<string, Combatant> = {};
  const initiatives: Array<{ id: string; init: number }> = [];

  for (const p of party) {
    const init = rollDice("1d20", rng).total + abilityMod(p.stats.dex);
    combatants[p.id] = { ...p, side: "party", initiative: init, statusEffects: [], isDown: false };
    initiatives.push({ id: p.id, init });
  }
  for (const e of enemies) {
    const init = rollDice("1d20", rng).total + abilityMod(e.stats.dex);
    combatants[e.id] = { ...e, side: "enemy", initiative: init, statusEffects: [], isDown: false };
    initiatives.push({ id: e.id, init });
  }

  initiatives.sort((a, b) => b.init - a.init);
  return {
    id: `combat_${Date.now()}`,
    round: 1,
    turnIdx: 0,
    order: initiatives.map((i) => i.id),
    combatants,
    log: [],
    finished: false,
  };
}

export interface AttackResult {
  hit: boolean;
  damage: number;
  rolls: number[];
  log: string;
}

export function resolveAttack(
  state: CombatState,
  attackerId: string,
  targetId: string,
  damageNotation: string,
  statKey: "str" | "dex" | "int" | "wis" | "cha" = "str",
  rng: () => number = Math.random,
): AttackResult {
  const attacker = state.combatants[attackerId];
  const target = state.combatants[targetId];
  if (!attacker || !target) throw new Error("Invalid combatant id");
  const attackRoll = rollDice("1d20", rng).total + abilityMod(attacker.stats[statKey]);
  const hit = attackRoll >= target.ac;
  let damage = 0;
  let rolls: number[] = [];
  if (hit) {
    const dmg = rollDice(damageNotation, rng);
    rolls = dmg.rolls;
    damage = Math.max(1, dmg.total + abilityMod(attacker.stats[statKey]));
    target.hp = Math.max(0, target.hp - damage);
    if (target.hp === 0) target.isDown = true;
  }
  const text = hit
    ? `${attacker.name} strikes ${target.name} for ${damage} damage.`
    : `${attacker.name} misses ${target.name}.`;
  state.log.push({ round: state.round, actorId: attackerId, text });
  return { hit, damage, rolls, log: text };
}

export function endTurn(state: CombatState): CombatState {
  let next = (state.turnIdx + 1) % state.order.length;
  let round = state.round;
  if (next === 0) round += 1;
  while (state.combatants[state.order[next]]?.isDown) {
    next = (next + 1) % state.order.length;
    if (next === state.turnIdx) break;
  }
  state.turnIdx = next;
  state.round = round;

  const partyAlive = Object.values(state.combatants).some((c) => c.side === "party" && !c.isDown);
  const enemyAlive = Object.values(state.combatants).some((c) => c.side === "enemy" && !c.isDown);
  if (!partyAlive || !enemyAlive) {
    state.finished = true;
    state.winner = partyAlive ? "party" : "enemy";
  }
  for (const c of Object.values(state.combatants)) {
    c.statusEffects = c.statusEffects
      .map((e) => ({ ...e, duration: e.duration - 1 }))
      .filter((e) => e.duration > 0);
  }
  return state;
}

export function currentActor(state: CombatState): Combatant {
  return state.combatants[state.order[state.turnIdx]];
}

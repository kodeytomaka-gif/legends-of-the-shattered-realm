export interface DiceRoll {
  notation: string;
  rolls: number[];
  modifier: number;
  total: number;
}

const NOTATION = /^(\d+)d(\d+)(?:([+-])(\d+))?$/i;

export function rollDice(notation: string, rng: () => number = Math.random): DiceRoll {
  const trimmed = notation.replace(/\s+/g, "");
  const match = NOTATION.exec(trimmed);
  if (!match) throw new Error(`Invalid dice notation: ${notation}`);
  const count = parseInt(match[1], 10);
  const sides = parseInt(match[2], 10);
  const sign = match[3] === "-" ? -1 : 1;
  const modifier = match[4] ? sign * parseInt(match[4], 10) : 0;
  if (count <= 0 || count > 100) throw new Error("Dice count out of range");
  if (sides <= 1 || sides > 1000) throw new Error("Dice sides out of range");
  const rolls: number[] = [];
  for (let i = 0; i < count; i++) {
    rolls.push(Math.floor(rng() * sides) + 1);
  }
  const total = rolls.reduce((a, b) => a + b, 0) + modifier;
  return { notation: trimmed, rolls, modifier, total };
}

export function abilityMod(score: number): number {
  return Math.floor((score - 10) / 2);
}

export function rollAbilityCheck(
  score: number,
  dc: number,
  rng: () => number = Math.random,
): { roll: number; mod: number; total: number; success: boolean } {
  const roll = Math.floor(rng() * 20) + 1;
  const mod = abilityMod(score);
  const total = roll + mod;
  return { roll, mod, total, success: total >= dc };
}

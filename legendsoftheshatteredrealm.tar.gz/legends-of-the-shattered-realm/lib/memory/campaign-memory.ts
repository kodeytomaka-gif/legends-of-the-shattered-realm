import { prisma } from "@/lib/prisma";

export interface MemoryEntry {
  category: string;
  key: string;
  value: string;
  weight?: number;
}

export async function remember(campaignId: string, entry: MemoryEntry) {
  return prisma.aiMemory.create({
    data: {
      campaignId,
      category: entry.category,
      key: entry.key,
      value: entry.value,
      weight: entry.weight ?? 1,
    },
  });
}

export async function recall(
  campaignId: string,
  opts: { category?: string; limit?: number } = {},
) {
  return prisma.aiMemory.findMany({
    where: {
      campaignId,
      category: opts.category,
    },
    orderBy: [{ weight: "desc" }, { createdAt: "desc" }],
    take: opts.limit ?? 20,
  });
}

export async function summarizeForStorySummary(campaignId: string): Promise<string> {
  const entries = await prisma.aiMemory.findMany({
    where: { campaignId },
    orderBy: [{ weight: "desc" }, { createdAt: "desc" }],
    take: 40,
  });
  if (entries.length === 0) return "";
  const grouped = new Map<string, string[]>();
  for (const e of entries) {
    if (!grouped.has(e.category)) grouped.set(e.category, []);
    grouped.get(e.category)!.push(`${e.key}: ${e.value}`);
  }
  return [...grouped.entries()]
    .map(([cat, items]) => `[${cat}]\n${items.join("\n")}`)
    .join("\n\n");
}

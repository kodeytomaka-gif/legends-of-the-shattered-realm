import type { Server as IoServer } from "socket.io";

let io: IoServer | null = null;

export function setIo(instance: IoServer) {
  io = instance;
}

export function getIo(): IoServer | null {
  return io;
}

export function emitToCampaign(campaignId: string, event: string, payload: unknown) {
  io?.to(`campaign:${campaignId}`).emit(event, payload);
}

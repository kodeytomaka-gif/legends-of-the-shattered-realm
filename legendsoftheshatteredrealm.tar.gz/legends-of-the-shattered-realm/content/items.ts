export interface ItemDef {
  externalId: string;
  name: string;
  description: string;
  rarity: "COMMON" | "UNCOMMON" | "RARE" | "EPIC" | "LEGENDARY";
  slot?: string;
  stats?: Record<string, number | string>;
  isUnique?: boolean;
}

export const ITEMS: ItemDef[] = [
  {
    externalId: "arming-sword",
    name: "Arming Sword",
    description: "Workmanlike steel. Honest blade.",
    rarity: "COMMON",
    slot: "hand1",
    stats: { damage: "1d8" },
  },
  {
    externalId: "longbow",
    name: "Yew Longbow",
    description: "A bow drawn from a tree older than the king.",
    rarity: "COMMON",
    slot: "hand1",
    stats: { damage: "1d8", range: 150 },
  },
  {
    externalId: "twin-daggers",
    name: "Twin Daggers",
    description: "Quiet, quick, and honest about what they are.",
    rarity: "COMMON",
    slot: "hand1",
    stats: { damage: "1d4+1d4", finesse: 1 },
  },
  {
    externalId: "kite-shield",
    name: "Kite Shield",
    description: "Iron-banded oak. The crest is yours to add.",
    rarity: "COMMON",
    slot: "hand2",
    stats: { ac: 2 },
  },
  {
    externalId: "chain-hauberk",
    name: "Chain Hauberk",
    description: "Cool against the skin, warm against the strike.",
    rarity: "COMMON",
    slot: "chest",
    stats: { ac: 14 },
  },
  {
    externalId: "leather-cuirass",
    name: "Leather Cuirass",
    description: "Worn supple. Whisper-quiet.",
    rarity: "COMMON",
    slot: "chest",
    stats: { ac: 12 },
  },
  {
    externalId: "scholar-robes",
    name: "Scholar's Robes",
    description: "Pockets enough for a library, sleeves enough for a flourish.",
    rarity: "COMMON",
    slot: "chest",
    stats: { ac: 10, spellFocus: 1 },
  },
  {
    externalId: "wolf-pelt-cloak",
    name: "Wolf-Pelt Cloak",
    description: "Still smells of the woods. Wolves leave you alone.",
    rarity: "UNCOMMON",
    slot: "trinket",
    stats: { coldResist: 1, intimidation: 1 },
  },
  {
    externalId: "pale-silver-ring",
    name: "Pale-Silver Ring",
    description: "A ring of cold silver. The wearer's blood runs slow but does not stop.",
    rarity: "UNCOMMON",
    slot: "trinket",
    stats: { necroticResist: 1, regen: 1 },
    isUnique: true,
  },
  {
    externalId: "stewards-lockpick",
    name: "Steward's Lockpick",
    description: "Speaks softly to old locks.",
    rarity: "RARE",
    stats: { lockpickBonus: 5 },
    isUnique: true,
  },
  {
    externalId: "wraiths-chain",
    name: "Wraith's Chain",
    description: "Iron links cold to the touch even in the sun. Binds what it strikes.",
    rarity: "UNCOMMON",
    slot: "hand1",
    stats: { damage: "1d6", chanceToRestrain: 0.2 },
  },
  {
    externalId: "old-watch-cloak",
    name: "Old Watch Cloak",
    description: "The seal of the Watch, blood-darkened. Some still salute it.",
    rarity: "RARE",
    slot: "trinket",
    stats: { wisSave: 1, fearImmune: 1 },
  },
  {
    externalId: "broken-oathblade",
    name: "Broken Oathblade",
    description: "Snapped at the cross-guard. Hums when held by someone who has kept a hard promise.",
    rarity: "EPIC",
    slot: "hand1",
    stats: { damage: "1d10+2", radiantOnVow: "1d8" },
    isUnique: true,
  },
  {
    externalId: "wardens-crown",
    name: "Warden's Crown",
    description: "A black-iron circlet, seven points, one bent inward. The kingdom did not give it; it took itself.",
    rarity: "LEGENDARY",
    slot: "head",
    stats: { allStats: 1, oathCharges: 3 },
    isUnique: true,
  },
  {
    externalId: "healing-draught",
    name: "Healing Draught",
    description: "Tastes like honeyed iron. Knits flesh.",
    rarity: "COMMON",
    stats: { healing: "2d4+2" },
  },
];

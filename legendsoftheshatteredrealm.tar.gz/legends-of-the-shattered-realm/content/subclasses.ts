export interface SubclassDef {
  id: string;
  classId: string;
  name: string;
  description: string;
  abilities: { level: number; id: string; name: string; description: string }[];
  passives: { id: string; name: string; description: string }[];
  ultimate: { id: string; name: string; description: string; cooldown: string };
}

export const SUBCLASSES: SubclassDef[] = [
  // Warrior
  {
    id: "berserker",
    classId: "warrior",
    name: "Berserker",
    description: "Embrace the red road. Rage as a sacrament.",
    abilities: [
      { level: 2, id: "rage", name: "Rage", description: "+2 melee damage, resistance to physical for 1 minute." },
      { level: 4, id: "reckless-strike", name: "Reckless Strike", description: "Attack with advantage; enemies gain advantage on you until next turn." },
      { level: 6, id: "intimidating-roar", name: "Intimidating Roar", description: "Frighten enemies within 30 ft." },
    ],
    passives: [{ id: "thick-skin", name: "Thick Skin", description: "+1 AC while raging." }],
    ultimate: {
      id: "blood-eclipse",
      name: "Blood Eclipse",
      description: "The Berserker becomes a storm of steel for 3 rounds: +3 attacks/turn, but takes 1d6 per turn.",
      cooldown: "Long Rest",
    },
  },
  {
    id: "guardian",
    classId: "warrior",
    name: "Guardian",
    description: "Be the shield. Be the wall. Be the last to fall.",
    abilities: [
      { level: 2, id: "interpose", name: "Interpose", description: "Reaction: take a hit aimed at an ally within 5 ft." },
      { level: 4, id: "shield-bash", name: "Shield Bash", description: "Action: knock prone on hit." },
      { level: 6, id: "iron-vow", name: "Iron Vow", description: "Mark an enemy; they have disadvantage attacking anyone but you." },
    ],
    passives: [{ id: "bulwark", name: "Bulwark", description: "Adjacent allies gain +1 AC." }],
    ultimate: {
      id: "last-stand",
      name: "Last Stand",
      description: "Drop to 1 HP instead of unconscious once per long rest; recover 2d8+CON.",
      cooldown: "Long Rest",
    },
  },
  // Ranger
  {
    id: "beast-hunter",
    classId: "ranger",
    name: "Beast Hunter",
    description: "Marked your prey. Now run it to ground.",
    abilities: [
      { level: 2, id: "favored-quarry", name: "Favored Quarry", description: "+1d6 vs marked enemy." },
      { level: 4, id: "trapper", name: "Trapper", description: "Set bear traps (1d10 restrain)." },
      { level: 6, id: "killing-edge", name: "Killing Edge", description: "Crits on 19-20 vs marked." },
    ],
    passives: [{ id: "tireless", name: "Tireless", description: "Half exhaustion on long marches." }],
    ultimate: {
      id: "death-volley",
      name: "Death Volley",
      description: "Fire 4 arrows, each vs different target, all with hunter's mark damage.",
      cooldown: "Long Rest",
    },
  },
  {
    id: "shadow-archer",
    classId: "ranger",
    name: "Shadow Archer",
    description: "The bow that does not sing.",
    abilities: [
      { level: 2, id: "ghost-step", name: "Ghost Step", description: "Move 30 ft without trace." },
      { level: 4, id: "hush-shot", name: "Hush Shot", description: "Silent ranged kill on unaware target ≤2 HD." },
      { level: 6, id: "dusk-cloak", name: "Dusk Cloak", description: "Invisible in dim light." },
    ],
    passives: [{ id: "soft-foot", name: "Soft Foot", description: "+5 Stealth when alone." }],
    ultimate: {
      id: "umbral-rain",
      name: "Umbral Rain",
      description: "Ranged attacks bend through cover for 1 minute. Cover does not protect from you.",
      cooldown: "Long Rest",
    },
  },
  // Rogue
  {
    id: "assassin",
    classId: "rogue",
    name: "Assassin",
    description: "One name, one breath, one knife.",
    abilities: [
      { level: 2, id: "death-strike", name: "Death Strike", description: "Crit on first strike vs surprised targets." },
      { level: 4, id: "poisons", name: "Poisons", description: "Apply poison: 2d6 Con save halves." },
      { level: 6, id: "infiltrator", name: "Infiltrator", description: "Disguise advantage; mimic voices passed once." },
    ],
    passives: [{ id: "patient-blade", name: "Patient Blade", description: "+2 Initiative." }],
    ultimate: {
      id: "name-of-night",
      name: "Name of Night",
      description: "Mark a target. The next strike, you may roll twice and take either; both crit on success.",
      cooldown: "Long Rest",
    },
  },
  {
    id: "treasure-seeker",
    classId: "rogue",
    name: "Treasure Seeker",
    description: "What's locked is yours, given time.",
    abilities: [
      { level: 2, id: "trap-sense", name: "Trap Sense", description: "+5 to spot traps; reaction to dodge." },
      { level: 4, id: "lockwhisper", name: "Lockwhisper", description: "Open any mundane lock in 1 round." },
      { level: 6, id: "gilded-tongue", name: "Gilded Tongue", description: "Advantage on persuasion when gold is involved." },
    ],
    passives: [{ id: "lucky-find", name: "Lucky Find", description: "Reroll loot table once per encounter." }],
    ultimate: {
      id: "ransack",
      name: "Ransack",
      description: "Empty an area's hidden loot in 30 seconds.",
      cooldown: "Long Rest",
    },
  },
  // Cleric
  {
    id: "lightbringer",
    classId: "cleric",
    name: "Lightbringer",
    description: "Carries the sun in their teeth.",
    abilities: [
      { level: 2, id: "warding-flare", name: "Warding Flare", description: "Reaction: impose disadvantage on attacker." },
      { level: 4, id: "burning-hands", name: "Burning Hands", description: "3d6 fire in 15 ft cone." },
      { level: 6, id: "daylight", name: "Daylight", description: "Bright light 60 ft; undead disadvantage." },
    ],
    passives: [{ id: "sun-touch", name: "Sun Touch", description: "Healing also damages adjacent undead for 1d6 radiant." }],
    ultimate: {
      id: "ascendant-dawn",
      name: "Ascendant Dawn",
      description: "Reveal the field, restore party to full HP, blind undead for 1 round.",
      cooldown: "Long Rest",
    },
  },
  {
    id: "grave-warden",
    classId: "cleric",
    name: "Grave Warden",
    description: "Speak for the unburied. Keep the doors shut.",
    abilities: [
      { level: 2, id: "path-to-grave", name: "Path to the Grave", description: "Mark target; next damage to them is doubled." },
      { level: 4, id: "speak-with-dead", name: "Speak with Dead", description: "Question a corpse for 1 minute." },
      { level: 6, id: "circle-of-mortality", name: "Circle of Mortality", description: "Maximize healing on 0-HP allies." },
    ],
    passives: [{ id: "patient-soul", name: "Patient Soul", description: "+2 vs necrotic damage." }],
    ultimate: {
      id: "sealed-door",
      name: "Sealed Door",
      description: "Banish one undead permanently from the campaign.",
      cooldown: "Once per Campaign",
    },
  },
  // Wizard
  {
    id: "elementalist",
    classId: "wizard",
    name: "Elementalist",
    description: "Reads the four tongues of the world.",
    abilities: [
      { level: 2, id: "elemental-attunement", name: "Elemental Attunement", description: "Switch a spell's damage type to fire/cold/lightning/acid." },
      { level: 4, id: "elemental-shield", name: "Elemental Shield", description: "Resist one element for 1 minute." },
      { level: 6, id: "twin-element", name: "Twin Element", description: "Cast same element-spell twice this turn." },
    ],
    passives: [{ id: "spark-touch", name: "Spark Touch", description: "Cantrips add +1 elemental damage." }],
    ultimate: {
      id: "tempest-circle",
      name: "Tempest Circle",
      description: "20 ft circle: 6d8 mixed elemental, lasts 3 rounds.",
      cooldown: "Long Rest",
    },
  },
  {
    id: "chronomancer",
    classId: "wizard",
    name: "Chronomancer",
    description: "Borrows now from later. Always pays it back.",
    abilities: [
      { level: 2, id: "haste-self", name: "Haste Self", description: "Extra action for 1 round." },
      { level: 4, id: "rewind", name: "Rewind", description: "Reaction: reroll a d20 within 6 seconds." },
      { level: 6, id: "still-the-clock", name: "Still the Clock", description: "Stop time for one enemy for 1 round." },
    ],
    passives: [{ id: "echo", name: "Echo", description: "First spell of combat costs no slot." }],
    ultimate: {
      id: "tomorrows-debt",
      name: "Tomorrow's Debt",
      description: "Take 3 turns in a row; lose your next 3.",
      cooldown: "Long Rest",
    },
  },
  // Paladin
  {
    id: "oathkeeper",
    classId: "paladin",
    name: "Oathkeeper",
    description: "Vow given. Vow held. Vow paid in steel.",
    abilities: [
      { level: 2, id: "vow-of-enmity", name: "Vow of Enmity", description: "Advantage vs marked target." },
      { level: 4, id: "purge", name: "Purge", description: "End one condition on ally as bonus action." },
      { level: 6, id: "oathbond", name: "Oathbond", description: "Allies within 10 ft cannot be charmed." },
    ],
    passives: [{ id: "steady-heart", name: "Steady Heart", description: "Immune to fear." }],
    ultimate: {
      id: "verdict",
      name: "Verdict",
      description: "Smite for 8d8 radiant; on hit, target is judged (no resurrection by foe).",
      cooldown: "Long Rest",
    },
  },
  {
    id: "vengeance-knight",
    classId: "paladin",
    name: "Vengeance Knight",
    description: "Some wrongs are bigger than mercy.",
    abilities: [
      { level: 2, id: "ire", name: "Ire", description: "Mark the wrongdoer; +1d6 vs them per round of combat." },
      { level: 4, id: "relentless", name: "Relentless", description: "Move toward marked target without difficult terrain." },
      { level: 6, id: "no-quarter", name: "No Quarter", description: "Crits on 19-20 vs marked." },
    ],
    passives: [{ id: "burning-oath", name: "Burning Oath", description: "+2 damage to humanoids that have wronged your party." }],
    ultimate: {
      id: "the-debt-paid",
      name: "The Debt Paid",
      description: "Spend half max HP, deal that x2 as radiant in a single strike.",
      cooldown: "Long Rest",
    },
  },
  // Druid
  {
    id: "wild-shaper",
    classId: "druid",
    name: "Wild Shaper",
    description: "Speaks the tongue of fur and feather.",
    abilities: [
      { level: 2, id: "form-of-the-beast", name: "Form of the Beast", description: "Become wolf/bear/eagle for 1 hour." },
      { level: 4, id: "primal-call", name: "Primal Call", description: "Summon 2 wolves for combat." },
      { level: 6, id: "thick-pelt", name: "Thick Pelt", description: "+2 AC while shaped." },
    ],
    passives: [{ id: "kin-of-claw", name: "Kin of Claw", description: "Beasts will not attack you unprovoked." }],
    ultimate: {
      id: "great-shape",
      name: "Great Shape",
      description: "Become a dire form (giant bear) for 5 rounds.",
      cooldown: "Long Rest",
    },
  },
  {
    id: "stormcaller",
    classId: "druid",
    name: "Stormcaller",
    description: "The sky answers when they call it.",
    abilities: [
      { level: 2, id: "shock", name: "Shock", description: "Cantrip: 1d8 lightning, can chain to second target on crit." },
      { level: 4, id: "call-lightning", name: "Call Lightning", description: "3d10 lightning bolt, recharge each turn." },
      { level: 6, id: "thunder-walk", name: "Thunder Walk", description: "Teleport via thundercrack 60 ft." },
    ],
    passives: [{ id: "stormbrood", name: "Stormbrood", description: "+1 to spell DC in rain/storm weather." }],
    ultimate: {
      id: "wrath-of-skies",
      name: "Wrath of Skies",
      description: "Storm lasts 1 minute. Each round, one foe takes 4d8 lightning.",
      cooldown: "Long Rest",
    },
  },
  // Bard
  {
    id: "lore-singer",
    classId: "bard",
    name: "Lore Singer",
    description: "Older songs cut deeper.",
    abilities: [
      { level: 2, id: "cutting-words", name: "Cutting Words", description: "Reaction: deduct 1d6 from enemy roll." },
      { level: 4, id: "knowledge-strike", name: "Knowledge Strike", description: "Bonus action: identify a weakness; +1d8 vs it for one strike." },
      { level: 6, id: "epic-recall", name: "Epic Recall", description: "Recall any campaign event verbatim." },
    ],
    passives: [{ id: "well-read", name: "Well-Read", description: "+2 to all knowledge checks." }],
    ultimate: {
      id: "song-of-the-shattered-crown",
      name: "Song of the Shattered Crown",
      description: "Allies hear themselves remembered; all gain +2 to attacks and saves for 3 rounds.",
      cooldown: "Long Rest",
    },
  },
  {
    id: "duelist-performer",
    classId: "bard",
    name: "Duelist Performer",
    description: "Every fight is a show. The crowd is paying attention.",
    abilities: [
      { level: 2, id: "flourish", name: "Flourish", description: "On crit, gain advantage on next attack." },
      { level: 4, id: "encore", name: "Encore", description: "On kill, recover bonus action." },
      { level: 6, id: "patter", name: "Patter", description: "Mock enemy: -2 to their next attack." },
    ],
    passives: [{ id: "showmanship", name: "Showmanship", description: "+2 Persuasion when an audience watches." }],
    ultimate: {
      id: "the-grand-curtain",
      name: "The Grand Curtain",
      description: "All visible enemies must Wis save or be charmed for 1 round.",
      cooldown: "Long Rest",
    },
  },
];

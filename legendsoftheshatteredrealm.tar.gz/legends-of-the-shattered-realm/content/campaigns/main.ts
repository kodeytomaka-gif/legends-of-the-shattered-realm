export const MAIN_CAMPAIGN = {
  id: "the-shattered-crown",
  title: "The Shattered Crown",
  pitch:
    "After the Shattering, the realm's crown was split into seven pieces. Three villains hunt the shards. The party will choose: who wears the crown, who breaks it, and who pays for either.",
  villains: [
    {
      id: "ashen-king",
      name: "The Ashen King",
      summary: "A reborn tyrant from before the Shattering, hollowed of name, hungry for it back.",
    },
    {
      id: "warden",
      name: "The Warden",
      summary: "The last paladin of the Old Watch. He keeps the door — from the wrong side. He may be redeemed; he may not.",
    },
    {
      id: "salt-witch",
      name: "The Salt Witch",
      summary: "Mistress of the river-dead. Trades names for power. Will offer the party a price they almost want to pay.",
    },
  ],
  prophecy:
    "Seven shards. Seven holders. The one who gathers all seven shall wear the Crown or destroy it. The realm shall be remade in their image.",
  chapters: [
    {
      number: 1,
      title: "Ashenford",
      summary: "The party arrives in Ashenford. A missing girl. A whispering wood. A crypt that should be sealed. They collect their first shard — and a name for the king.",
      keyLocations: ["ashenford", "whispering-woods", "old-crypt"],
      playable: true,
    },
    {
      number: 2,
      title: "The River and the Salt",
      summary: "The Salt Witch makes her offer. The party meets the cost of crossing — and the cost of refusing.",
      keyLocations: ["river-crossing"],
      playable: false,
    },
    {
      number: 3,
      title: "The Banner Marches",
      summary: "The Old Watch banners stir. The Warden is sighted. The party gathers the second through fourth shards.",
      keyLocations: [],
      playable: false,
    },
    {
      number: 4,
      title: "The Court of Ash",
      summary: "The Ashen King's court — a city of ash. The fifth and sixth shards. A betrayal.",
      keyLocations: [],
      playable: false,
    },
    {
      number: 5,
      title: "The Watchtower",
      summary: "The seventh shard. The Warden waits. Four endings: The Sword Path. The Quiet Path. The Mercy Path. The Inheritor Path.",
      keyLocations: ["forgotten-watchtower"],
      playable: true,
    },
  ],
  memorySeeds: [
    {
      category: "world",
      key: "The Shattering",
      value: "Two centuries ago, the realm's crown was broken into seven shards. The kingdom never quite came back.",
      weight: 5,
    },
    {
      category: "world",
      key: "The Old Watch",
      value: "An order of paladins sworn to keep the door at the Forgotten Watchtower. Disbanded after their oath broke.",
      weight: 4,
    },
    {
      category: "world",
      key: "Ashenford geography",
      value: "Frontier town on the southern road. Bell Plaza (markets), Veiled Quarter (smugglers), Old Wall (Magistrate), Conservatory (bards).",
      weight: 3,
    },
  ],
};

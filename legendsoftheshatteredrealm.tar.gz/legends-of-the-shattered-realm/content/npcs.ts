export interface NpcDef {
  externalId: string;
  name: string;
  description: string;
  faction?: string;
  locationExternalId?: string;
  dialogueHints?: string;
}

export const NPCS: NpcDef[] = [
  {
    externalId: "edda-merchant",
    name: "Edda Stonemarker",
    description: "Spice and tin merchant of Bell Plaza. Sharp tongue. Sharp grief. Her daughter Nessa is missing.",
    faction: "Merchants' Guild",
    locationExternalId: "ashenford",
    dialogueHints: "Will pay 50 gp + safe passage south for the return of Nessa. Suspects the Veiled Quarter; the Magistrate refused to listen.",
  },
  {
    externalId: "magistrate-corvan",
    name: "Magistrate Corvan",
    description: "Tall, thin, tired. Holds the law in Ashenford the way a man holds a leaking bowl.",
    faction: "Magistracy",
    locationExternalId: "ashenford",
    dialogueHints: "Useful but cautious. Will not act against the Veiled Quarter without provable cause. Will lend a city writ if persuaded.",
  },
  {
    externalId: "hadric-bellkeeper",
    name: "Old Hadric",
    description: "Bell-tower keeper. Drinks. Sees more than he lets on. Knows the Veiled Quarter's rhythms.",
    faction: "Independent",
    locationExternalId: "ashenford",
    dialogueHints: "5 gp loosens him. Knows which cellar in the Crooked Cup hides what.",
  },
  {
    externalId: "warden-circle-elder",
    name: "Elder Iona of the Hollow Oak",
    description: "Warden's Circle druid. Old eyes, older patience. Speaks for the woods.",
    faction: "Warden's Circle",
    locationExternalId: "whispering-woods",
    dialogueHints: "Cares about the shrine, the wolves, the balance. Will teach Wild Shape technique to druids who restore the shrine.",
  },
  {
    externalId: "grave-steward-cellan",
    name: "Cellan, Steward of the Long Silence",
    description: "A Grave Warden cleric, very old. Keeps watch from the chapel above the Old Crypt.",
    faction: "Grave Stewards",
    locationExternalId: "old-crypt",
    dialogueHints: "Will teach the Stewards' Words to a cleric who hears the doors. Will not enter the crypt himself anymore; his duty is to remember.",
  },
  {
    externalId: "river-merchant",
    name: "Salt-Dealer Mab",
    description: "Sells salt at three times the usual price right at the riverbank. Knows exactly why.",
    faction: "Independent",
    locationExternalId: "river-crossing",
    dialogueHints: "Cynical, friendly, expensive. Will tell the soldier's name the wraith wants — for 20 gp or a story she hasn't heard.",
  },
];

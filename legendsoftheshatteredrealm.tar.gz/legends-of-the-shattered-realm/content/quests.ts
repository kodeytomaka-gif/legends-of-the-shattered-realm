export interface QuestOptionDef {
  id: string;
  type: "combat" | "stealth" | "diplomacy" | "creative";
  label: string;
  description: string;
  risk: "low" | "medium" | "high" | "deadly";
  reward: string;
  requirements: string;
}

export interface QuestDef {
  externalId: string;
  locationExternalId: string;
  title: string;
  description: string;
  options: QuestOptionDef[];
}

export const QUESTS: QuestDef[] = [
  {
    externalId: "the-missing-daughter",
    locationExternalId: "ashenford",
    title: "The Missing Daughter",
    description:
      "Merchant Edda's daughter Nessa was last seen at the Veiled Quarter four nights ago. The Magistrate will not look there.",
    options: [
      {
        id: "kick-the-door",
        type: "combat",
        label: "Storm the Crooked Cup tavern",
        description: "The smugglers run that house. Cut through to the cellar.",
        risk: "high",
        reward: "Direct lead, hostile city watch.",
        requirements: "Party of two or more.",
      },
      {
        id: "shadow-the-cup",
        type: "stealth",
        label: "Shadow the Cup at dusk",
        description: "Watch the cellar door, follow the smuggler who locks it.",
        risk: "medium",
        reward: "Patient lead, hidden passage.",
        requirements: "Stealth ≥ 12.",
      },
      {
        id: "buy-the-truth",
        type: "diplomacy",
        label: "Pay the bell-keeper for what he saw",
        description: "Old Hadric watches the Quarter. He drinks. 5 gold loosens him.",
        risk: "low",
        reward: "Name and a face.",
        requirements: "5 gp.",
      },
      {
        id: "lantern-lure",
        type: "creative",
        label: "Set a lantern at the bridge with her name on it",
        description: "Veiled Quarter superstition: name on lantern draws who took her.",
        risk: "medium",
        reward: "Unexpected ally appears.",
        requirements: "Knowledge: Folklore.",
      },
    ],
  },
  {
    externalId: "wolves-at-the-shrine",
    locationExternalId: "whispering-woods",
    title: "Wolves at the Hollow Shrine",
    description:
      "The Hollow Oak shrine is overrun by wolves driven from their dens. The Warden's Circle wants it kept clean.",
    options: [
      {
        id: "drive-them-out",
        type: "combat",
        label: "Drive the pack out",
        description: "Pack of six wolves, one alpha.",
        risk: "medium",
        reward: "Wolf-pelt cloak (uncommon).",
        requirements: "Party melee or ranged.",
      },
      {
        id: "ambush-alpha",
        type: "stealth",
        label: "Pick off the alpha",
        description: "Without the alpha the pack scatters.",
        risk: "medium",
        reward: "Pack disperses; no other gain.",
        requirements: "Ranged + Stealth.",
      },
      {
        id: "feed-them",
        type: "diplomacy",
        label: "Offer them the deer carcass nearby",
        description: "The pack is starving. Offer makes a pact.",
        risk: "low",
        reward: "Wolves remember you (faction: Wild +5).",
        requirements: "Animal Handling.",
      },
      {
        id: "wake-the-oak",
        type: "creative",
        label: "Wake the Hollow Oak",
        description: "Reignite the shrine. The oak warns the pack home.",
        risk: "medium",
        reward: "+1 max HP to all party members.",
        requirements: "Cleric or Druid.",
      },
    ],
  },
  {
    externalId: "the-sealed-door",
    locationExternalId: "old-crypt",
    title: "The Sealed Door",
    description:
      "Deep in the Old Crypt: a door marked with the Steward's Seal. Behind it, the Wight stirs.",
    options: [
      {
        id: "break-it",
        type: "combat",
        label: "Break the door and face the Wight",
        description: "Direct confrontation. Wight + 4 ghouls.",
        risk: "deadly",
        reward: "Pale-Silver Ring + 800 xp.",
        requirements: "Party L3+.",
      },
      {
        id: "slip-past",
        type: "stealth",
        label: "Slip past via the bone-stair",
        description: "Side corridor. Avoid the boss room entirely.",
        risk: "medium",
        reward: "Steward's Lockpick (rare); Wight remains.",
        requirements: "Stealth ≥ 15.",
      },
      {
        id: "speak-the-seal",
        type: "diplomacy",
        label: "Speak the Stewards' words",
        description: "If you know the words, the seal recognizes you.",
        risk: "low",
        reward: "Wight bows; +1 favor with Grave-Wardens.",
        requirements: "Cleric (Grave Warden) OR known Stewards' tongue.",
      },
      {
        id: "drown-the-room",
        type: "creative",
        label: "Flood the chamber from the cistern above",
        description: "The Wight is bound to dust. Water unmakes its anchor.",
        risk: "medium",
        reward: "Wight destroyed; ring lost.",
        requirements: "Knowledge: Architecture + 1 minute.",
      },
    ],
  },
  {
    externalId: "the-bridge-toll",
    locationExternalId: "river-crossing",
    title: "The Bridge Toll",
    description:
      "The wraith at Wraithwater Crossing demands toll. Salt, not coin. Some pay it. Some try not to.",
    options: [
      {
        id: "fight-the-wraith",
        type: "combat",
        label: "Refuse and fight",
        description: "Wraith + 2 grasping shades.",
        risk: "high",
        reward: "Wraith's chain (uncommon); river will not forgive.",
        requirements: "Party L2+ with silvered weapons.",
      },
      {
        id: "ford-downstream",
        type: "stealth",
        label: "Ford the river downstream",
        description: "Cold, slow, sneaky.",
        risk: "medium",
        reward: "Exhaustion; no combat.",
        requirements: "Survival ≥ 12.",
      },
      {
        id: "pay-the-toll",
        type: "diplomacy",
        label: "Pay the salt, speak the name",
        description: "The wraith asks the name of a soldier it remembers.",
        risk: "low",
        reward: "Safe passage; +1 favor with the river.",
        requirements: "1 lb salt + History check.",
      },
      {
        id: "name-it-back",
        type: "creative",
        label: "Give it back its own name",
        description: "Wraiths who hear their living name may sometimes pass on.",
        risk: "high",
        reward: "Wraith dissolves; receive River's Boon.",
        requirements: "Lore Singer (Bard) OR Speak with Dead.",
      },
    ],
  },
  {
    externalId: "the-warden-of-the-watchtower",
    locationExternalId: "forgotten-watchtower",
    title: "The Warden of the Watchtower",
    description:
      "The Warden waits at the top of the tower. He was the kingdom's last oath. It broke him. Now he keeps the door — from the wrong side.",
    options: [
      {
        id: "duel-the-warden",
        type: "combat",
        label: "Climb the tower and duel him, blade to blade",
        description: "Three-phase fight: blade, banner, broken oath.",
        risk: "deadly",
        reward: "Warden's Crown (legendary); ending: The Sword Path.",
        requirements: "Party L5+.",
      },
      {
        id: "scale-the-back",
        type: "stealth",
        label: "Scale the tower's back and reach the seal-room",
        description: "Bypass the Warden, seal the door from inside.",
        risk: "high",
        reward: "Seal restored; ending: The Quiet Path.",
        requirements: "Stealth ≥ 18; rope.",
      },
      {
        id: "remind-him-of-his-name",
        type: "diplomacy",
        label: "Remind him of his name",
        description: "If you have collected his old oaths through the campaign, you may speak them back.",
        risk: "high",
        reward: "Warden lays down arms; ending: The Mercy Path.",
        requirements: "Collected ≥ 3 Warden memories during campaign.",
      },
      {
        id: "rewrite-the-oath",
        type: "creative",
        label: "Rewrite the Oath at the altar",
        description: "Take the broken oath into yourself. Become bound to keep what he kept.",
        risk: "deadly",
        reward: "One party member becomes the new Warden; ending: The Inheritor Path.",
        requirements: "Paladin OR a player who has held the campaign's central artifact.",
      },
    ],
  },
];

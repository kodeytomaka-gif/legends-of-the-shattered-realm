export interface FactionDef {
  externalId: string;
  name: string;
  description: string;
}

export const FACTIONS: FactionDef[] = [
  {
    externalId: "magistracy",
    name: "The Magistracy of Ashenford",
    description: "The law, such as it is. Polite, brittle, willing to be useful if you give them deniability.",
  },
  {
    externalId: "wardens-circle",
    name: "The Warden's Circle",
    description: "Druids and rangers who keep the old wards. Slow to act, hard to break.",
  },
  {
    externalId: "grave-stewards",
    name: "The Grave Stewards",
    description: "Clerics of the long silence. Keep what should stay sleeping, sleeping. Their seal is older than the kingdom.",
  },
];

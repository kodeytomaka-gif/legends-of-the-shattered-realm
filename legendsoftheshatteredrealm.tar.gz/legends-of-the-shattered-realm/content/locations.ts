export interface LocationDef {
  externalId: string;
  name: string;
  type: "town" | "wilderness" | "dungeon" | "ruin" | "arena";
  description: string;
  lore: string;
  parentExternalId?: string;
  startingLocation?: boolean;
  payload?: Record<string, unknown>;
}

export const LOCATIONS: LocationDef[] = [
  {
    externalId: "ashenford",
    name: "Town of Ashenford",
    type: "town",
    description:
      "A frontier town built on the bones of an older kingdom. Bell-tower, bridges, brackish wells. Lanterns burn even at noon.",
    lore: "After the Shattering, Ashenford was where the southern roads ended and the lawful world thinned out. The Magistrate keeps order with a thin blade. The Veiled Quarter keeps its own.",
    startingLocation: true,
    payload: {
      districts: ["Bell Plaza", "Veiled Quarter", "Old Wall", "Conservatory"],
      hooks: ["A merchant's daughter has gone missing.", "Bell-tower keeper is afraid of the dark."],
    },
  },
  {
    externalId: "whispering-woods",
    name: "The Whispering Woods",
    type: "wilderness",
    description: "Birch and old oak. The wind says names you do not recognize but cannot dismiss.",
    lore: "The Warden's Circle once warded these woods. The wards are old now. Things walk the inner glades that no map shows.",
    payload: {
      encounters: ["wolf-pack", "fey-glade", "bandit-camp"],
      secrets: ["Hollow Oak shrine grants +1 max HP once per character."],
    },
  },
  {
    externalId: "old-crypt",
    name: "The Old Crypt",
    type: "dungeon",
    description: "Stone stair under a forgotten chapel. Air old as Olympus. The candles light themselves.",
    lore: "Built by the Grave-Stewards before the Shattering. Their seal still holds — barely.",
    payload: {
      levels: 3,
      boss: "crypt-wight",
      lootHint: "Pale-Silver Ring (uncommon).",
    },
  },
  {
    externalId: "river-crossing",
    name: "Wraithwater Crossing",
    type: "wilderness",
    description: "A stone bridge over a river the locals will not name. Tolls are paid in salt, not coin.",
    lore: "Drowned soldiers from a war that did not end. The bridge has its own rules.",
    payload: { encounters: ["toll-wraith", "river-merchant"] },
  },
  {
    externalId: "forgotten-watchtower",
    name: "The Forgotten Watchtower",
    type: "arena",
    description: "A black tower at the realm's edge. Its top stair waits.",
    lore: "Built to watch for the thing the kingdom forgot to fear. The Warden was once a paladin; it is no longer.",
    payload: { boss: "warden-of-the-watchtower", phases: 3 },
  },
];

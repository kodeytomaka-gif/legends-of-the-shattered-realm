export interface BossDef {
  id: string;
  name: string;
  isMajor: boolean;
  lore: string;
  arena: string;
  mechanics: {
    hp: number;
    ac: number;
    phases?: { hpThreshold: number; abilities: string[]; description: string }[];
    passives: string[];
    immunities: string[];
  };
  lootTable: { itemId: string; chance: number }[];
  dialogue: { intro: string; phase?: string[]; defeat: string };
}

export const BOSSES: BossDef[] = [
  {
    id: "crypt-wight",
    name: "The Crypt Wight",
    isMajor: false,
    lore: "Once a Steward who refused to lie down. Three centuries of refusal have made it cruel.",
    arena: "The sealed chamber of the Old Crypt.",
    mechanics: {
      hp: 90,
      ac: 16,
      passives: ["regenerates 5 HP at start of each turn while in shadow"],
      immunities: ["poison", "necrotic"],
      phases: [
        {
          hpThreshold: 60,
          description: "Stands before the seal, sword sheathed in moth-dust.",
          abilities: ["draining-grasp (2d8 necrotic + level drain)", "rebuke"],
        },
        {
          hpThreshold: 30,
          description: "The seal cracks. Four ghouls climb out and stand at his back.",
          abilities: ["call-ghouls (summon 2 ghouls)", "shadow-blade (3d8 cold)"],
        },
      ],
    },
    lootTable: [
      { itemId: "pale-silver-ring", chance: 1 },
      { itemId: "stewards-lockpick", chance: 0.3 },
    ],
    dialogue: {
      intro: "I am still standing. Tell them, when you go down: I am still standing.",
      phase: ["I do not need this body. I need only refuse."],
      defeat: "Tell them. Tell them I was here.",
    },
  },
  {
    id: "warden-of-the-watchtower",
    name: "The Warden of the Watchtower",
    isMajor: true,
    lore: "Sir Aedric of the Bell-Roads, last paladin of the Old Watch. Broke his oath to keep his men alive. He was right; the kingdom called him wrong; the oath called him both.",
    arena: "The tower-top, ringed by the seven banners of the Old Watch, all stained.",
    mechanics: {
      hp: 280,
      ac: 19,
      passives: [
        "while a banner stands, gains +1 attack",
        "after each phase, kneels and stands again with +5 max HP regen",
      ],
      immunities: ["fear", "charm"],
      phases: [
        {
          hpThreshold: 220,
          description: "Phase 1: The Blade. He fights as he always fought — clean, brutal, by the book.",
          abilities: [
            "great-cleave (2d12 slashing in arc)",
            "bell-strike (knockback 15 ft + stunned 1 turn)",
            "oath-bind (one PC cannot leave 30 ft for 2 rounds)",
          ],
        },
        {
          hpThreshold: 120,
          description: "Phase 2: The Banner. The seven banners flare red. He calls his men's ghosts back to fight beside him.",
          abilities: [
            "summon-shade (3 Old Watch shades, 30 HP each)",
            "for-the-watch (shades take a hit for him, reaction)",
            "voice-of-command (allied shades attack twice)",
          ],
        },
        {
          hpThreshold: 0,
          description: "Phase 3: The Broken Oath. The banners fall. He breaks them himself. He stops fighting like a knight and starts fighting like a thing.",
          abilities: [
            "no-mercy (3 attacks per turn)",
            "verdict-of-the-grave (target Con save or instant down)",
            "shattered-crown (radiant burst: 5d10 in 20 ft, then 1 HP)",
          ],
        },
      ],
    },
    lootTable: [
      { itemId: "wardens-crown", chance: 1 },
      { itemId: "broken-oathblade", chance: 1 },
      { itemId: "old-watch-cloak", chance: 0.7 },
    ],
    dialogue: {
      intro: "I told them. I told them what was coming. They named me oathbreaker for telling. Come up, then. Try to name me anything.",
      phase: [
        "The Watch never lay down. The Watch never lay down. The Watch—",
        "I remember each of you. I remember your names. I do not care.",
      ],
      defeat: "...the door. Keep the door. Tell them the door.",
    },
  },
];

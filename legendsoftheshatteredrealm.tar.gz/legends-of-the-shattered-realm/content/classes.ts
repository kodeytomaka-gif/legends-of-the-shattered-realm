export interface ClassDef {
  id: string;
  name: string;
  description: string;
  loreText: string;
  baseStats: { str: number; dex: number; con: number; int: number; wis: number; cha: number };
  startingEquipment: string[];
  growthPath: {
    primaryStat: "str" | "dex" | "con" | "int" | "wis" | "cha";
    hpPerLevel: number;
    abilitiesByLevel: Record<string, string[]>;
  };
}

export const CLASSES: ClassDef[] = [
  {
    id: "warrior",
    name: "Warrior",
    description: "Iron-bound veterans of a hundred fields. Stands the line.",
    loreText:
      "From the legion-keeps of Vaelhold to the orphan-shields of Ashenford, warriors are forged. They are the wall the realm sleeps behind.",
    baseStats: { str: 16, dex: 12, con: 14, int: 10, wis: 10, cha: 10 },
    startingEquipment: ["arming-sword", "kite-shield", "chain-hauberk"],
    growthPath: {
      primaryStat: "str",
      hpPerLevel: 8,
      abilitiesByLevel: {
        "1": ["cleave", "second-wind"],
        "3": ["shield-bash"],
        "5": ["whirlwind"],
      },
    },
  },
  {
    id: "ranger",
    name: "Ranger",
    description: "Wardens of the wild places. Eye, bow, and bond.",
    loreText: "The Wardens of the Whispering Woods walk where roads end. Theirs is the long sight, the long breath, the long shot.",
    baseStats: { str: 12, dex: 16, con: 12, int: 10, wis: 14, cha: 10 },
    startingEquipment: ["longbow", "short-sword", "leather-cuirass"],
    growthPath: {
      primaryStat: "dex",
      hpPerLevel: 7,
      abilitiesByLevel: {
        "1": ["hunters-mark", "track"],
        "3": ["volley"],
        "5": ["camouflage"],
      },
    },
  },
  {
    id: "rogue",
    name: "Rogue",
    description: "Daggers in the dark, locks in the night, gold in the morning.",
    loreText: "The Veiled Quarter of Ashenford runs on whispers. Rogues collect them, sell them, and sometimes silence them.",
    baseStats: { str: 10, dex: 17, con: 12, int: 12, wis: 12, cha: 12 },
    startingEquipment: ["twin-daggers", "leather-armor", "thieves-tools"],
    growthPath: {
      primaryStat: "dex",
      hpPerLevel: 6,
      abilitiesByLevel: {
        "1": ["sneak-attack", "disengage"],
        "3": ["uncanny-dodge"],
        "5": ["shadow-step"],
      },
    },
  },
  {
    id: "cleric",
    name: "Cleric",
    description: "Vessels of divine fire. Healer, judge, and lamp.",
    loreText: "From the Sun-Choirs of Therin to the Grave-Stewards of the Old Crypt, clerics carry their god in their palms.",
    baseStats: { str: 13, dex: 10, con: 13, int: 10, wis: 16, cha: 12 },
    startingEquipment: ["maul", "wooden-shield", "scale-mail", "holy-symbol"],
    growthPath: {
      primaryStat: "wis",
      hpPerLevel: 7,
      abilitiesByLevel: {
        "1": ["healing-word", "guiding-bolt"],
        "3": ["spirit-guardians"],
        "5": ["mass-heal"],
      },
    },
  },
  {
    id: "wizard",
    name: "Wizard",
    description: "Scholars of the Weave. Names move the world.",
    loreText: "The Arcanum of Thelvain teaches that every spell is first a sentence. The wise keep their grammar clean.",
    baseStats: { str: 8, dex: 12, con: 12, int: 17, wis: 12, cha: 10 },
    startingEquipment: ["quarterstaff", "spellbook", "scholar-robes"],
    growthPath: {
      primaryStat: "int",
      hpPerLevel: 5,
      abilitiesByLevel: {
        "1": ["magic-missile", "shield", "light"],
        "3": ["fireball"],
        "5": ["counterspell"],
      },
    },
  },
  {
    id: "paladin",
    name: "Paladin",
    description: "Vow-bound knights. Blade as prayer, oath as armor.",
    loreText: "The Oathwall of the Watchtower remembers every name that ever broke an oath. Paladins ride to keep theirs.",
    baseStats: { str: 15, dex: 10, con: 13, int: 10, wis: 12, cha: 14 },
    startingEquipment: ["long-sword", "tower-shield", "scale-mail", "holy-symbol"],
    growthPath: {
      primaryStat: "str",
      hpPerLevel: 8,
      abilitiesByLevel: {
        "1": ["divine-smite", "lay-on-hands"],
        "3": ["aura-of-protection"],
        "5": ["radiant-strike"],
      },
    },
  },
  {
    id: "druid",
    name: "Druid",
    description: "Children of the green. Speaks for storms and stones.",
    loreText: "The Circle of the Hollow Oak does not ask the forest's permission. They are the forest, in another shape.",
    baseStats: { str: 10, dex: 12, con: 13, int: 12, wis: 16, cha: 10 },
    startingEquipment: ["sickle", "wooden-shield", "hide-armor", "druidic-focus"],
    growthPath: {
      primaryStat: "wis",
      hpPerLevel: 7,
      abilitiesByLevel: {
        "1": ["entangle", "wild-shape"],
        "3": ["call-lightning"],
        "5": ["wall-of-thorns"],
      },
    },
  },
  {
    id: "bard",
    name: "Bard",
    description: "Word-smiths and string-wielders. Story is a weapon.",
    loreText: "The Conservatory of Ashenford insists music is a kind of swordsmanship. The graveyards behind it tend to agree.",
    baseStats: { str: 10, dex: 14, con: 12, int: 12, wis: 12, cha: 16 },
    startingEquipment: ["rapier", "lute", "leather-armor"],
    growthPath: {
      primaryStat: "cha",
      hpPerLevel: 6,
      abilitiesByLevel: {
        "1": ["vicious-mockery", "inspiration"],
        "3": ["cutting-words"],
        "5": ["hypnotic-pattern"],
      },
    },
  },
];

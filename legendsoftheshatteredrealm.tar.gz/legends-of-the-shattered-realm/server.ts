/* eslint-disable @typescript-eslint/no-explicit-any */
import { createServer } from "node:http";
import { parse } from "node:url";
import next from "next";
import { Server as IoServer } from "socket.io";
import { setIo } from "./lib/socket";

const dev = process.env.NODE_ENV !== "production";
const hostname = process.env.HOSTNAME ?? "0.0.0.0";
const port = parseInt(process.env.PORT ?? "3000", 10);

async function start() {
  const app = next({ dev, hostname, port });
  const handle = app.getRequestHandler();
  await app.prepare();

  const server = createServer((req, res) => {
    const parsedUrl = parse(req.url ?? "", true);
    handle(req, res, parsedUrl);
  });

  const io = new IoServer(server, {
    path: "/socket.io",
    cors: { origin: "*", methods: ["GET", "POST"] },
  });

  io.on("connection", (socket) => {
    socket.on("campaign:subscribe", (campaignId: string) => {
      if (typeof campaignId !== "string") return;
      socket.join(`campaign:${campaignId}`);
      socket.emit("campaign:subscribed", { campaignId });
    });

    socket.on("campaign:unsubscribe", (campaignId: string) => {
      socket.leave(`campaign:${campaignId}`);
    });

    socket.on("disconnect", () => {
      // no-op
    });
  });

  setIo(io);

  server.listen(port, hostname, () => {
    console.log(`> Ready on http://${hostname}:${port} (Socket.IO at /socket.io)`);
  });
}

start().catch((err) => {
  console.error(err);
  process.exit(1);
});

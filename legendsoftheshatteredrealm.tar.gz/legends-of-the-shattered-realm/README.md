# Legends of the Shattered Realm

A browser-based fantasy roleplaying platform with an AI Dungeon Master. Host a campaign, gather up to four friends (or pass the device around a table), and play through a branching story where the storyteller never tires.

## v1 status

This repo is a **vertical-slice MVP**. The full game architecture is in place — auth, campaign + character creation, AI DM orchestration with provider-agnostic adapter, turn-based combat engine, progression, story memory, multiplayer over Socket.IO — and ships with a trimmed but playable amount of seed content.

What ships in v1:
- 8 classes × 2 subclasses (16 subclasses) — fully defined.
- 5 locations, 5 quests (each with four distinct approaches: combat, stealth, diplomacy, creative).
- 2 bosses (1 minor, 1 major three-phase).
- ~15 items across rarities.
- Main campaign "The Shattered Crown" — chapter 1 fully playable; chapters 2–5 outlined as DM memory seeds.
- 6 NPCs, 3 factions.
- Online + Local + Hybrid modes.
- Anthropic and local-LLM providers are stubbed (interface only) for easy swap later.

Roadmap (out of scope for v1):
- Remaining ~7 locations, ~15 quests, ~6 bosses, full talent-tree UI past level 5.
- Vector-embedding memory retrieval (column exists; retrieval falls back to recency + weight).
- Animated map with fog-of-war / tokens / sound design.
- Production deploy config.

## Tech

- Next.js 15 (App Router) + TypeScript + Tailwind CSS
- PostgreSQL via Prisma
- NextAuth (Credentials)
- OpenAI (default DM provider) — Anthropic + local stubs
- Socket.IO via custom Next.js server
- Zod for validation
- Vitest (unit) + Playwright (e2e)

## Setup

```bash
pnpm install
cp .env.example .env
# Edit .env: DATABASE_URL, NEXTAUTH_SECRET, OPENAI_API_KEY
pnpm db:generate
pnpm db:push          # or pnpm db:migrate
pnpm db:seed
pnpm dev              # custom server boots Next + Socket.IO on http://localhost:3000
```

## Golden path (manual verification)

1. Open two browser profiles.
2. Profile A: register → create campaign (mode ONLINE) → copy invite code.
3. Profile B: register → join with code.
4. Each profile: forge a character (class + subclass).
5. Profile A: enter `/campaigns/<id>/play`, type a first action (e.g. "look around the bell plaza").
6. The DM narrates and presents four actions tagged combat / stealth / diplomacy / creative.
7. Pick a `combat` option to start a fight, or `diplomacy` to advance a quest.
8. Confirm: HP / XP / quests persist across reloads; Profile B sees the same narration in real time.
9. Visit `/table` to start a local pass-and-play campaign — same engine, no accounts required.

## AI provider swap

In `.env`:
```
AI_PROVIDER=openai     # or "anthropic" / "local"
```
The Anthropic and Local providers are currently stubs — implement `lib/ai/providers/anthropic.ts` or `local.ts` using the `AiProvider` interface in `lib/ai/adapter.ts` to enable them.

## Tests

```bash
pnpm test                 # vitest unit
pnpm test:e2e             # playwright (requires running server)
```

## Architecture notes

- `lib/ai/orchestrator.ts` is the single chokepoint between the game and the AI. All requests funnel through it; all responses are Zod-validated; all state mutations happen in a single Prisma transaction.
- `lib/ai/schemas.ts` enforces the **four-approach rule** at the schema level — every decision point returns combat + stealth + diplomacy + creative options.
- World/story/character/combat/quest state stores live under `lib/game/state/`, decoupled from the AI model entirely. Swapping providers does not touch game logic.
- `content/*.ts` files are the authored seed data. To add a new quest, edit `content/quests.ts` and re-run `pnpm db:seed`.
- Multiplayer uses Socket.IO rooms keyed by `campaign:<id>`. Local and Hybrid modes use the same orchestrator — only the transport differs.

## License

Private — not for redistribution.

import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import CharacterCreator from "@/components/game/CharacterCreator";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function CharacterPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await getServerSession(authOptions);
  const userId = (session?.user as { id?: string } | undefined)?.id;

  const campaign = await prisma.campaign.findUnique({
    where: { id },
    include: { players: { include: { character: true } } },
  });
  if (!campaign) return <main className="p-12">Campaign not found.</main>;

  const player =
    campaign.players.find((p) => userId && p.userId === userId) ??
    campaign.players.find((p) => p.isHost && !userId) ??
    null;

  if (!player) {
    return (
      <main className="mx-auto max-w-2xl px-6 py-16">
        <h1 className="font-display text-3xl text-gold-400">No player slot</h1>
        <p className="mt-3 text-parchment-200/80">
          You are not registered to this campaign. Use the invite code first.
        </p>
        <Link href="/join" className="gold-btn mt-6 inline-block">
          Join with Code
        </Link>
      </main>
    );
  }

  if (player.character) {
    return (
      <main className="mx-auto max-w-2xl px-6 py-16">
        <h1 className="font-display text-3xl text-gold-400">Character forged</h1>
        <p className="mt-3 text-parchment-200/85">Your hero waits for the road.</p>
        <Link href={`/campaigns/${id}/play`} className="gold-btn mt-6 inline-block">
          Step into the world
        </Link>
      </main>
    );
  }

  const classes = await prisma.class.findMany({
    include: { subclasses: true },
    orderBy: { name: "asc" },
  });

  return (
    <main className="mx-auto max-w-5xl px-6 py-12">
      <h1 className="font-display text-4xl text-gold-400">Forge Your Hero</h1>
      <p className="mt-2 text-parchment-200/85">
        Pick a class, then a subclass. Your choice colors the road ahead.
      </p>
      <CharacterCreator
        campaignId={id}
        playerId={player.id}
        classes={classes.map((c) => ({
          id: c.id,
          name: c.name,
          description: c.description,
          loreText: c.loreText,
          subclasses: c.subclasses.map((s) => ({
            id: s.id,
            name: s.name,
            description: s.description,
          })),
        }))}
      />
    </main>
  );
}

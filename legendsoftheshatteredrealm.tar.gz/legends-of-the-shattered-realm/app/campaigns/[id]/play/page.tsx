import { prisma } from "@/lib/prisma";
import PlayClient from "@/components/game/PlayClient";

export const dynamic = "force-dynamic";

export default async function PlayPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const campaign = await prisma.campaign.findUnique({
    where: { id },
    include: {
      players: {
        include: { character: { include: { class: true, subclass: true } } },
      },
      messages: { orderBy: { createdAt: "asc" }, take: 80 },
      quests: true,
    },
  });
  if (!campaign) return <main className="p-12">Campaign not found.</main>;

  const currentLocation = campaign.currentLocationId
    ? await prisma.location.findUnique({ where: { id: campaign.currentLocationId } })
    : null;

  return (
    <PlayClient
      campaign={{
        id: campaign.id,
        name: campaign.name,
        inviteCode: campaign.inviteCode,
        mode: campaign.mode,
        storySummary: campaign.storySummary,
      }}
      currentLocation={
        currentLocation
          ? { id: currentLocation.id, name: currentLocation.name, description: currentLocation.description }
          : null
      }
      party={campaign.players
        .filter((p): p is typeof p & { character: NonNullable<typeof p.character> } => !!p.character)
        .map((p) => ({
          id: p.id,
          displayName: p.displayName,
          characterId: p.character.id,
          characterName: p.character.name,
          className: p.character.class.name,
          subclassName: p.character.subclass?.name ?? null,
          level: p.character.level,
          hp: p.character.hp,
          maxHp: p.character.maxHp,
        }))}
      messages={campaign.messages.map((m) => ({
        id: m.id,
        role: m.role,
        content: m.content,
        payload: (m.payload as Record<string, unknown> | null) ?? null,
        createdAt: m.createdAt.toISOString(),
      }))}
      quests={campaign.quests.map((q) => ({
        id: q.id,
        title: q.title,
        status: q.status,
      }))}
    />
  );
}

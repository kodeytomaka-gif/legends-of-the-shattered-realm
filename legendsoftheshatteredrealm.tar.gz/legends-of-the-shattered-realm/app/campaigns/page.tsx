import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function CampaignsList() {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as { id?: string } | undefined)?.id;
  let campaigns: { id: string; name: string; mode: string; inviteCode: string; updatedAt: Date }[] = [];
  if (userId) {
    const rows = await prisma.campaign.findMany({
      where: {
        OR: [{ hostId: userId }, { players: { some: { userId } } }],
      },
      orderBy: { updatedAt: "desc" },
    });
    campaigns = rows.map((c) => ({
      id: c.id,
      name: c.name,
      mode: c.mode,
      inviteCode: c.inviteCode,
      updatedAt: c.updatedAt,
    }));
  }

  return (
    <main className="mx-auto max-w-5xl px-6 py-16">
      <div className="flex items-center justify-between mb-8">
        <h1 className="font-display text-4xl text-gold-400">Campaigns</h1>
        <div className="flex gap-3">
          <Link href="/campaigns/new" className="gold-btn">
            New Campaign
          </Link>
          <Link href="/join" className="ghost-btn">
            Join with Code
          </Link>
        </div>
      </div>

      {!session?.user && (
        <div className="rune-card">
          <p className="text-parchment-200/90">
            <Link href="/login" className="text-gold-400 underline">Sign in</Link> to see your saved campaigns, or
            <Link href="/table" className="text-gold-400 underline ml-1">start a local table</Link>.
          </p>
        </div>
      )}

      {session?.user && campaigns.length === 0 && (
        <div className="rune-card text-parchment-200/90">
          You have no campaigns yet. Host one to begin.
        </div>
      )}

      <div className="grid gap-4 mt-4">
        {campaigns.map((c) => (
          <Link
            key={c.id}
            href={`/campaigns/${c.id}/play`}
            className="rune-card hover:shadow-rune transition-shadow flex items-center justify-between"
          >
            <div>
              <div className="font-display text-xl text-gold-400">{c.name}</div>
              <div className="text-sm text-parchment-200/70 mt-1">
                {c.mode} · code <span className="font-mono">{c.inviteCode}</span> · updated {new Date(c.updatedAt).toLocaleString()}
              </div>
            </div>
            <span className="text-gold-400 font-display">Enter →</span>
          </Link>
        ))}
      </div>
    </main>
  );
}

"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";

export default function NewCampaign() {
  const router = useRouter();
  const { data: session } = useSession();
  const [name, setName] = useState("The Shattered Crown");
  const [hostDisplayName, setHostDisplayName] = useState(
    session?.user?.name ?? "Game Master",
  );
  const [mode, setMode] = useState<"ONLINE" | "LOCAL" | "HYBRID">("ONLINE");
  const [description, setDescription] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const res = await fetch("/api/campaigns", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ name, description, mode, hostDisplayName }),
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(typeof data.error === "string" ? data.error : "Could not create campaign.");
      setBusy(false);
      return;
    }
    const { id } = await res.json();
    router.push(`/campaigns/${id}/character`);
  }

  return (
    <main className="mx-auto max-w-2xl px-6 py-16">
      <h1 className="font-display text-4xl text-gold-400">Host a Campaign</h1>
      <p className="mt-2 text-parchment-200/85">
        Forge the stage. The realm answers names.
      </p>
      <form onSubmit={onSubmit} className="mt-8 space-y-5 rune-card">
        <Field label="Campaign Name">
          <input
            className="input"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </Field>
        <Field label="Your Display Name">
          <input
            className="input"
            value={hostDisplayName}
            onChange={(e) => setHostDisplayName(e.target.value)}
            required
          />
        </Field>
        <Field label="Mode">
          <select
            className="input"
            value={mode}
            onChange={(e) => setMode(e.target.value as "ONLINE" | "LOCAL" | "HYBRID")}
          >
            <option value="ONLINE">Online (invite friends)</option>
            <option value="LOCAL">Local Table (pass-and-play)</option>
            <option value="HYBRID">Hybrid (some at the table, some remote)</option>
          </select>
        </Field>
        <Field label="Pitch (optional)">
          <textarea
            className="input min-h-[100px]"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="One paragraph the DM should remember."
          />
        </Field>
        {error && <p className="text-ember-500 text-sm">{error}</p>}
        <div className="flex gap-3">
          <button className="gold-btn" disabled={busy}>
            {busy ? "Lighting the brazier..." : "Begin"}
          </button>
        </div>
      </form>
      <style jsx>{`
        :global(.input) {
          width: 100%;
          background: rgba(15, 12, 8, 0.6);
          border: 1px solid rgba(212, 175, 55, 0.35);
          color: #ede0bf;
          padding: 0.6rem 0.8rem;
          border-radius: 0.4rem;
        }
        :global(.input:focus) {
          outline: none;
          border-color: #d4af37;
          box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.15);
        }
      `}</style>
    </main>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="block text-sm font-display tracking-wider text-gold-400 mb-1">{label}</span>
      {children}
    </label>
  );
}

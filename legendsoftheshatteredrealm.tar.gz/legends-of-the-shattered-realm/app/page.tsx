import Link from "next/link";

export default function Landing() {
  return (
    <main className="relative overflow-hidden">
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-ink-900 via-ink-800 to-ink-900" />
      <div className="absolute inset-x-0 top-0 -z-10 h-[60vh] bg-[radial-gradient(ellipse_at_top,rgba(212,175,55,0.18),transparent_70%)]" />

      <section className="mx-auto max-w-5xl px-6 py-24 text-center">
        <p className="font-display tracking-[0.4em] text-gold-500 text-sm">
          ⚔  AN AI DUNGEON MASTER  ⚔
        </p>
        <h1 className="font-display text-5xl md:text-7xl mt-6 text-parchment-50 leading-tight">
          Legends of the
          <br />
          Shattered Realm
        </h1>
        <p className="mt-8 max-w-2xl mx-auto text-lg text-parchment-200/90">
          Host a campaign. Gather your party. Step into a world where the
          choices are yours, the consequences are real, and the storyteller
          never tires.
        </p>
        <div className="mt-10 flex flex-wrap justify-center gap-4">
          <Link href="/campaigns/new" className="gold-btn">
            Host a Campaign
          </Link>
          <Link href="/join" className="ghost-btn">
            Join with Code
          </Link>
          <Link href="/table" className="ghost-btn">
            Local Table
          </Link>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-6 px-6 pb-24 md:grid-cols-3">
        <Feature
          title="The Storyteller"
          body="An AI Dungeon Master that remembers your decisions, voices your villains, and adapts the story to the party you become."
        />
        <Feature
          title="Four Paths Always"
          body="Every choice offers combat, stealth, diplomacy, and a creative path. No fake choices. Every decision shapes the realm."
        />
        <Feature
          title="Play Anywhere"
          body="Host online with up to four friends. Run a pass-and-play local table. Mix both in hybrid mode. The world goes where you go."
        />
      </section>
    </main>
  );
}

function Feature({ title, body }: { title: string; body: string }) {
  return (
    <div className="rune-card">
      <h3 className="font-display text-2xl text-gold-400">{title}</h3>
      <p className="mt-3 text-parchment-200/85 leading-relaxed">{body}</p>
    </div>
  );
}

import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const schema = z.object({
  inviteCode: z.string().min(4).max(8),
  displayName: z.string().min(1).max(40),
});

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.format() }, { status: 400 });

  const campaign = await prisma.campaign.findUnique({
    where: { inviteCode: parsed.data.inviteCode.toUpperCase() },
  });
  if (!campaign) return NextResponse.json({ error: "Invalid invite code" }, { status: 404 });
  if (campaign.mode === "LOCAL") {
    return NextResponse.json({ error: "Local campaigns do not accept remote joins" }, { status: 400 });
  }

  const existing = await prisma.player.findFirst({
    where: { campaignId: campaign.id, userId: (session?.user as { id?: string })?.id ?? null },
  });
  if (existing) {
    return NextResponse.json({ campaignId: campaign.id, playerId: existing.id });
  }

  const player = await prisma.player.create({
    data: {
      campaignId: campaign.id,
      userId: (session?.user as { id?: string })?.id ?? null,
      isLocal: !session?.user,
      displayName: parsed.data.displayName,
    },
  });

  return NextResponse.json({ campaignId: campaign.id, playerId: player.id });
}

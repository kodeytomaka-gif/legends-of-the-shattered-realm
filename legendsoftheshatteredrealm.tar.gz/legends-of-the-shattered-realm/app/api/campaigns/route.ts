import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { createCampaign } from "@/lib/campaign/create";

const schema = z.object({
  name: z.string().min(1).max(80),
  description: z.string().max(500).optional(),
  mode: z.enum(["ONLINE", "LOCAL", "HYBRID"]),
  hostDisplayName: z.string().min(1).max(40),
});

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.format() }, { status: 400 });
  }
  if (parsed.data.mode !== "LOCAL" && !session?.user) {
    return NextResponse.json({ error: "Sign in required for online/hybrid campaigns." }, { status: 401 });
  }

  const campaign = await createCampaign({
    name: parsed.data.name,
    description: parsed.data.description,
    hostUserId: (session?.user as { id?: string })?.id,
    hostDisplayName: parsed.data.hostDisplayName,
    mode: parsed.data.mode,
  });

  return NextResponse.json({
    id: campaign.id,
    inviteCode: campaign.inviteCode,
    mode: campaign.mode,
  });
}

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ campaigns: [] });
  const userId = (session.user as { id?: string }).id;
  if (!userId) return NextResponse.json({ campaigns: [] });
  const campaigns = await prisma.campaign.findMany({
    where: {
      OR: [
        { hostId: userId },
        { players: { some: { userId } } },
      ],
    },
    orderBy: { updatedAt: "desc" },
  });
  return NextResponse.json({ campaigns });
}

import { NextResponse } from "next/server";
import { z } from "zod";
import { runDmTurn, type SceneKind } from "@/lib/ai/orchestrator";
import { emitToCampaign } from "@/lib/socket";

const schema = z.object({
  text: z.string().min(1).max(2000),
  chosenActionId: z.string().optional(),
  sceneKind: z.enum(["exploration", "combat", "quest", "encounter"]).optional(),
});

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id: campaignId } = await params;
  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.format() }, { status: 400 });

  try {
    const result = await runDmTurn({
      campaignId,
      playerActionText: parsed.data.text,
      chosenActionId: parsed.data.chosenActionId,
      sceneKind: parsed.data.sceneKind as SceneKind | undefined,
    });
    emitToCampaign(campaignId, "dm:update", result.response);
    return NextResponse.json(result);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

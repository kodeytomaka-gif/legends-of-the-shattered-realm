import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const campaign = await prisma.campaign.findUnique({
    where: { id },
    include: {
      players: { include: { character: true } },
      locations: true,
      quests: true,
      storyEvents: { orderBy: { createdAt: "asc" } },
      npcs: true,
      factions: true,
      aiMemories: true,
      messages: { orderBy: { createdAt: "asc" } },
    },
  });
  if (!campaign) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const save = await prisma.save.create({
    data: {
      campaignId: id,
      label: `Manual save ${new Date().toISOString()}`,
      snapshotJson: campaign as unknown as object,
    },
  });
  return NextResponse.json({ saveId: save.id });
}

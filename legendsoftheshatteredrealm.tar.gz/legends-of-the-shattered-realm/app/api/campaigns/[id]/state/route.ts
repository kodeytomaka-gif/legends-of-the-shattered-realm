import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const campaign = await prisma.campaign.findUnique({
    where: { id },
    include: {
      players: {
        include: { character: { include: { class: true, subclass: true } } },
      },
      locations: { where: { discovered: true } },
      quests: true,
      messages: { orderBy: { createdAt: "asc" }, take: 100 },
    },
  });
  if (!campaign) return NextResponse.json({ error: "Not found" }, { status: 404 });

  let currentLocation = null;
  if (campaign.currentLocationId) {
    currentLocation = await prisma.location.findUnique({
      where: { id: campaign.currentLocationId },
    });
  }
  return NextResponse.json({ campaign, currentLocation });
}

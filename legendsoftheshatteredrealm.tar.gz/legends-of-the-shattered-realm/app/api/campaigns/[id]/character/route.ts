import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { createCharacter } from "@/lib/campaign/character";

const schema = z.object({
  playerId: z.string(),
  name: z.string().min(1).max(40),
  classId: z.string(),
  subclassId: z.string().optional(),
});

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id: campaignId } = await params;
  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.format() }, { status: 400 });

  const player = await prisma.player.findUnique({ where: { id: parsed.data.playerId } });
  if (!player || player.campaignId !== campaignId) {
    return NextResponse.json({ error: "Player not in campaign" }, { status: 403 });
  }
  const existing = await prisma.character.findUnique({ where: { playerId: parsed.data.playerId } });
  if (existing) return NextResponse.json({ error: "Character already exists" }, { status: 409 });

  const character = await createCharacter({
    playerId: parsed.data.playerId,
    name: parsed.data.name,
    classId: parsed.data.classId,
    subclassId: parsed.data.subclassId,
  });
  return NextResponse.json({ characterId: character.id });
}

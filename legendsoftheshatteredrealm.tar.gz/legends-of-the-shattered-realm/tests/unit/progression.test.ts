import { describe, it, expect } from "vitest";
import { levelForXp, xpToNext, applyLevelUp } from "@/lib/game/progression";

describe("progression", () => {
  it("computes level from xp", () => {
    expect(levelForXp(0)).toBe(1);
    expect(levelForXp(299)).toBe(1);
    expect(levelForXp(300)).toBe(2);
    expect(levelForXp(900)).toBe(3);
    expect(levelForXp(2700)).toBe(4);
  });

  it("reports xp to next", () => {
    const next = xpToNext(500);
    expect(next.current).toBe(300);
    expect(next.next).toBe(900);
    expect(next.needed).toBe(400);
  });

  it("levels up and grants abilities", () => {
    const growth = {
      abilitiesByLevel: { "2": ["rage"], "3": ["shield-bash"] },
    };
    const r = applyLevelUp(1500, 1, 14, growth);
    expect(r.leveledUp).toBe(true);
    expect(r.newLevel).toBe(3);
    expect(r.newAbilities).toContain("rage");
    expect(r.newAbilities).toContain("shield-bash");
    expect(r.hpGain).toBeGreaterThan(0);
  });
});

import { describe, it, expect } from "vitest";
import { DmResponseSchema, validateFourApproaches } from "@/lib/ai/schemas";

const SAMPLE = {
  narration: "A bell tolls.",
  scene: { location: "Ashenford", mood: "uneasy", environment: "cold rain" },
  npcs: [],
  actions: [
    { id: "a1", type: "combat", label: "Strike", description: "Draw and cut.", risk: "medium", requirements: "none" },
    { id: "a2", type: "stealth", label: "Slip", description: "Slide into the cellar.", risk: "low", requirements: "Stealth 12" },
    { id: "a3", type: "diplomacy", label: "Speak", description: "Talk them down.", risk: "low", requirements: "none" },
    { id: "a4", type: "creative", label: "Light", description: "Cast Light.", risk: "low", requirements: "any caster" },
  ],
  storyUpdates: [],
  questUpdates: [],
  combat: { startCombat: false, enemies: [] },
  rewards: { xp: 0, gold: 0, items: [], reputation: [] },
  hint: "Pick a path.",
};

describe("DM schema", () => {
  it("validates a well-formed response", () => {
    const r = DmResponseSchema.safeParse(SAMPLE);
    expect(r.success).toBe(true);
  });

  it("requires all four approach types", () => {
    const onlyThree = SAMPLE.actions.slice(0, 3);
    const check = validateFourApproaches(onlyThree as never);
    expect(check.ok).toBe(false);
    expect(check.missing).toContain("creative");
  });

  it("flags duplicate approaches as ok when all four present", () => {
    const dupe = [
      ...SAMPLE.actions,
      {
        id: "a5",
        type: "combat" as const,
        label: "Extra",
        description: "Repeat.",
        risk: "low" as const,
        requirements: "none",
      },
    ];
    const check = validateFourApproaches(dupe as never);
    expect(check.ok).toBe(true);
  });
});

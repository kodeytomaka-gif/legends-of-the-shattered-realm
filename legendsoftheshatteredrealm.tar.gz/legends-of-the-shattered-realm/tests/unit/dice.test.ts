import { describe, it, expect } from "vitest";
import { rollDice, abilityMod, rollAbilityCheck } from "@/lib/game/dice";

describe("dice", () => {
  it("parses and rolls 2d6+3", () => {
    let i = 0;
    const seq = [0.1, 0.5, 0.9]; // results: 1, 4, ?
    const rng = () => seq[i++ % seq.length];
    const result = rollDice("2d6+3", rng);
    expect(result.rolls).toHaveLength(2);
    expect(result.modifier).toBe(3);
    expect(result.total).toBe(result.rolls.reduce((a, b) => a + b, 0) + 3);
  });

  it("rejects invalid notation", () => {
    expect(() => rollDice("garbage")).toThrow();
    expect(() => rollDice("0d6")).toThrow();
  });

  it("computes ability modifier", () => {
    expect(abilityMod(10)).toBe(0);
    expect(abilityMod(16)).toBe(3);
    expect(abilityMod(8)).toBe(-1);
  });

  it("rolls ability check with DC", () => {
    const r = rollAbilityCheck(16, 12, () => 0.99); // roll 20 + 3
    expect(r.success).toBe(true);
    expect(r.total).toBe(23);
  });
});

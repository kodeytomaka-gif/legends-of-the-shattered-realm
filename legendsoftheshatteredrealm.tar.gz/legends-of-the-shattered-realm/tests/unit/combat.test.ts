import { describe, it, expect } from "vitest";
import { startCombat, resolveAttack, endTurn } from "@/lib/game/combat-engine";

const stats = { str: 16, dex: 12, con: 14, int: 10, wis: 10, cha: 10 };

describe("combat-engine", () => {
  it("rolls initiative and orders combatants", () => {
    const state = startCombat(
      [{ id: "p1", name: "Aedan", hp: 20, maxHp: 20, ac: 16, stats }],
      [{ id: "e1", name: "Ghoul", hp: 12, maxHp: 12, ac: 12, stats: { ...stats, dex: 8 } }],
      () => 0.99,
    );
    expect(state.order).toHaveLength(2);
    expect(state.combatants.p1.initiative).toBeGreaterThan(0);
  });

  it("resolves a hit", () => {
    const state = startCombat(
      [{ id: "p1", name: "Aedan", hp: 20, maxHp: 20, ac: 16, stats }],
      [{ id: "e1", name: "Ghoul", hp: 12, maxHp: 12, ac: 10, stats }],
      () => 0.99,
    );
    const r = resolveAttack(state, "p1", "e1", "1d8", "str", () => 0.99);
    expect(r.hit).toBe(true);
    expect(r.damage).toBeGreaterThan(0);
    expect(state.combatants.e1.hp).toBeLessThan(12);
  });

  it("ends combat when one side is down", () => {
    const state = startCombat(
      [{ id: "p1", name: "Aedan", hp: 20, maxHp: 20, ac: 16, stats }],
      [{ id: "e1", name: "Goblin", hp: 1, maxHp: 1, ac: 8, stats }],
      () => 0.99,
    );
    resolveAttack(state, "p1", "e1", "1d8", "str", () => 0.99);
    endTurn(state);
    expect(state.finished).toBe(true);
    expect(state.winner).toBe("party");
  });
});

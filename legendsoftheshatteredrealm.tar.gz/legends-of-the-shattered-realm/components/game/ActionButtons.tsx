"use client";

import type { DmAction, DmApproach } from "@/lib/ai/schemas";

const APPROACH_META: Record<DmApproach, { label: string; glyph: string; color: string }> = {
  combat: { label: "Combat", glyph: "⚔", color: "border-ember-500/60" },
  stealth: { label: "Stealth", glyph: "☾", color: "border-ink-700" },
  diplomacy: { label: "Diplomacy", glyph: "✿", color: "border-gold-500/60" },
  creative: { label: "Creative", glyph: "✺", color: "border-moss-500/60" },
};

export default function ActionButtons({
  actions,
  onChoose,
  disabled,
}: {
  actions: DmAction[];
  onChoose: (a: DmAction) => void;
  disabled?: boolean;
}) {
  return (
    <div className="grid gap-3 md:grid-cols-2">
      {actions.map((a) => {
        const meta = APPROACH_META[a.type] ?? APPROACH_META.creative;
        return (
          <button
            key={a.id}
            onClick={() => onChoose(a)}
            disabled={disabled}
            className={`rune-card text-left border-2 ${meta.color} hover:shadow-rune transition disabled:opacity-60`}
          >
            <div className="flex items-center justify-between">
              <span className="font-display text-sm tracking-widest text-gold-400">
                {meta.glyph} {meta.label}
              </span>
              <span className="text-xs uppercase text-parchment-200/60">
                {a.risk}
              </span>
            </div>
            <h4 className="font-display text-lg text-parchment-50 mt-1">
              {a.label}
            </h4>
            <p className="text-sm text-parchment-200/80 mt-1 leading-relaxed">
              {a.description}
            </p>
            {a.requirements && a.requirements !== "none" && (
              <p className="text-xs text-parchment-200/60 mt-2 italic">
                Requires: {a.requirements}
              </p>
            )}
          </button>
        );
      })}
    </div>
  );
}

"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { cn } from "@/lib/utils";

interface SubclassOpt {
  id: string;
  name: string;
  description: string;
}
interface ClassOpt {
  id: string;
  name: string;
  description: string;
  loreText: string;
  subclasses: SubclassOpt[];
}

export default function CharacterCreator(props: {
  campaignId: string;
  playerId: string;
  classes: ClassOpt[];
}) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [classId, setClassId] = useState<string | null>(null);
  const [subclassId, setSubclassId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const chosenClass = props.classes.find((c) => c.id === classId);

  async function onSubmit() {
    if (!classId || !name) return;
    setBusy(true);
    setError(null);
    const res = await fetch(`/api/campaigns/${props.campaignId}/character`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        playerId: props.playerId,
        name,
        classId,
        subclassId: subclassId ?? undefined,
      }),
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(typeof data.error === "string" ? data.error : "Could not forge character.");
      setBusy(false);
      return;
    }
    router.push(`/campaigns/${props.campaignId}/play`);
  }

  return (
    <div className="mt-8 grid gap-6 md:grid-cols-3">
      <div className="md:col-span-1 rune-card">
        <label className="block">
          <span className="block text-sm font-display tracking-wider text-gold-400 mb-1">Name</span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full bg-ink-900/60 border border-gold-500/40 text-parchment-100 rounded-md px-3 py-2 focus:outline-none focus:border-gold-400"
            placeholder="Aedan, Marrowsong, ..."
          />
        </label>
        {chosenClass && (
          <div className="mt-6">
            <h3 className="font-display text-xl text-gold-400">{chosenClass.name}</h3>
            <p className="text-sm text-parchment-200/80 mt-2 leading-relaxed">{chosenClass.loreText}</p>
          </div>
        )}
        {error && <p className="text-ember-500 text-sm mt-4">{error}</p>}
        <button
          onClick={onSubmit}
          disabled={!classId || !name || busy}
          className="gold-btn w-full mt-6"
        >
          {busy ? "Forging..." : "Forge Hero"}
        </button>
      </div>

      <div className="md:col-span-2 grid gap-3">
        <div>
          <h3 className="font-display text-2xl text-gold-400">Class</h3>
          <div className="grid sm:grid-cols-2 gap-3 mt-3">
            {props.classes.map((c) => (
              <button
                key={c.id}
                onClick={() => {
                  setClassId(c.id);
                  setSubclassId(null);
                }}
                className={cn(
                  "rune-card text-left transition-shadow",
                  classId === c.id && "shadow-rune",
                )}
              >
                <div className="font-display text-lg text-gold-400">{c.name}</div>
                <p className="text-sm text-parchment-200/80 mt-1">{c.description}</p>
              </button>
            ))}
          </div>
        </div>

        {chosenClass && chosenClass.subclasses.length > 0 && (
          <div className="mt-4">
            <h3 className="font-display text-2xl text-gold-400">Subclass</h3>
            <div className="grid sm:grid-cols-2 gap-3 mt-3">
              {chosenClass.subclasses.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setSubclassId(s.id)}
                  className={cn(
                    "rune-card text-left transition-shadow",
                    subclassId === s.id && "shadow-rune",
                  )}
                >
                  <div className="font-display text-lg text-gold-400">{s.name}</div>
                  <p className="text-sm text-parchment-200/80 mt-1">{s.description}</p>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

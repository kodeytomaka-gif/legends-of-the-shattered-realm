"use client";

export default function QuestList({
  quests,
}: {
  quests: { id: string; title: string; status: string }[];
}) {
  return (
    <div className="rune-card">
      <h3 className="font-display text-lg text-gold-400">Journal</h3>
      <ul className="mt-3 space-y-1.5">
        {quests.length === 0 && (
          <li className="text-sm text-parchment-200/60 italic">
            No quests inked.
          </li>
        )}
        {quests.map((q) => (
          <li key={q.id} className="flex items-center gap-2 text-sm">
            <span
              className={
                q.status === "COMPLETED"
                  ? "text-moss-500"
                  : q.status === "FAILED"
                    ? "text-ember-500"
                    : q.status === "ACTIVE"
                      ? "text-gold-400"
                      : "text-parchment-200/60"
              }
            >
              {q.status === "COMPLETED" ? "✓" : q.status === "FAILED" ? "✗" : "❖"}
            </span>
            <span className="text-parchment-100/90">{q.title}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

"use client";

export interface PartyMemberData {
  id: string;
  displayName: string;
  characterId: string;
  characterName: string;
  className: string;
  subclassName: string | null;
  level: number;
  hp: number;
  maxHp: number;
}

export default function PartySidebar({ party }: { party: PartyMemberData[] }) {
  return (
    <div className="rune-card">
      <h3 className="font-display text-lg text-gold-400">Party</h3>
      <div className="mt-3 space-y-3">
        {party.length === 0 && (
          <p className="text-sm text-parchment-200/60 italic">
            No heroes yet. Share the code.
          </p>
        )}
        {party.map((m) => {
          const pct = Math.round((m.hp / Math.max(1, m.maxHp)) * 100);
          return (
            <div key={m.id} className="border border-gold-500/15 rounded-md p-2">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-display text-parchment-50">
                    {m.characterName}
                  </div>
                  <div className="text-xs text-parchment-200/70">
                    L{m.level} {m.className}
                    {m.subclassName ? ` · ${m.subclassName}` : ""}
                  </div>
                  <div className="text-[10px] text-parchment-200/50">
                    as {m.displayName}
                  </div>
                </div>
              </div>
              <div className="mt-2 h-2 bg-ink-700 rounded-full overflow-hidden">
                <div
                  className="h-full bg-ember-500/80"
                  style={{ width: `${pct}%` }}
                />
              </div>
              <div className="text-[10px] text-parchment-200/60 mt-1 text-right">
                HP {m.hp} / {m.maxHp}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

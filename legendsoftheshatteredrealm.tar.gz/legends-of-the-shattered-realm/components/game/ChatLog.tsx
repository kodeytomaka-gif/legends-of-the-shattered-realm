"use client";

import { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";

export interface ChatMessageData {
  id: string;
  role: "PLAYER" | "DM" | "SYSTEM";
  content: string;
  payload: Record<string, unknown> | null;
  createdAt: string;
}

export default function ChatLog({ messages }: { messages: ChatMessageData[] }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    ref.current?.scrollTo({ top: ref.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  return (
    <div
      ref={ref}
      className="rune-card flex-1 max-h-[60vh] overflow-y-auto scroll-thin space-y-4"
    >
      {messages.length === 0 && (
        <p className="text-parchment-200/60 italic">
          The storyteller draws a breath. Speak your first action below.
        </p>
      )}
      {messages.map((m) => (
        <div
          key={m.id}
          className={cn(
            "rounded-md px-4 py-3 border",
            m.role === "DM"
              ? "bg-ink-900/60 border-gold-500/30"
              : m.role === "PLAYER"
                ? "bg-moss-600/30 border-moss-500/40"
                : "bg-ember-600/15 border-ember-500/30",
          )}
        >
          <div className="text-xs font-display tracking-wider mb-1">
            {m.role === "DM" && (
              <span className="text-gold-400">⚯ Storyteller</span>
            )}
            {m.role === "PLAYER" && (
              <span className="text-parchment-100">▸ Party</span>
            )}
            {m.role === "SYSTEM" && <span className="text-ember-500">▲ System</span>}
          </div>
          <p className="whitespace-pre-wrap leading-relaxed text-parchment-100/95">
            {m.content}
          </p>
        </div>
      ))}
    </div>
  );
}

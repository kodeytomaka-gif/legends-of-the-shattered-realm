"use client";

import { useEffect, useState } from "react";
import type { DmResponse } from "@/lib/ai/schemas";
import ActionButtons from "./ActionButtons";
import ChatLog, { ChatMessageData } from "./ChatLog";
import PartySidebar, { PartyMemberData } from "./PartySidebar";
import QuestList from "./QuestList";

interface Props {
  campaign: {
    id: string;
    name: string;
    inviteCode: string;
    mode: string;
    storySummary: string | null;
  };
  currentLocation: { id: string; name: string; description: string } | null;
  party: PartyMemberData[];
  messages: ChatMessageData[];
  quests: { id: string; title: string; status: string }[];
}

export default function PlayClient(props: Props) {
  const [messages, setMessages] = useState<ChatMessageData[]>(props.messages);
  const [actions, setActions] = useState<DmResponse["actions"]>([]);
  const [scene, setScene] = useState<DmResponse["scene"] | null>(null);
  const [combatActive, setCombatActive] = useState(false);
  const [busy, setBusy] = useState(false);
  const [inputText, setInputText] = useState("");

  // Hydrate the latest DM message's actions on mount
  useEffect(() => {
    const lastDm = [...props.messages].reverse().find((m) => m.role === "DM");
    if (lastDm?.payload) {
      const payload = lastDm.payload as unknown as DmResponse;
      if (payload.actions) setActions(payload.actions);
      if (payload.scene) setScene(payload.scene);
      if (payload.combat?.startCombat) setCombatActive(true);
    }
  }, [props.messages]);

  // Cross-client realtime sync is handled when running the custom Socket.IO
  // server (`pnpm dev:realtime`). On Vercel/serverless, the action POST
  // returns the DM response directly — each client refreshes to see others'
  // moves. Pusher/Ably can be wired here later for live multiplayer.

  function onDmResponse(response: DmResponse) {
    setMessages((m) => [
      ...m,
      {
        id: `dm-${Date.now()}`,
        role: "DM",
        content: response.narration,
        payload: response as unknown as Record<string, unknown>,
        createdAt: new Date().toISOString(),
      },
    ]);
    setActions(response.actions);
    setScene(response.scene);
    if (response.combat?.startCombat) setCombatActive(true);
  }

  async function submitAction(text: string, chosenActionId?: string) {
    if (!text.trim() || busy) return;
    setBusy(true);
    setMessages((m) => [
      ...m,
      {
        id: `local-${Date.now()}`,
        role: "PLAYER",
        content: text,
        payload: null,
        createdAt: new Date().toISOString(),
      },
    ]);
    try {
      const res = await fetch(`/api/campaigns/${props.campaign.id}/action`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          text,
          chosenActionId,
          sceneKind: combatActive ? "combat" : "quest",
        }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setMessages((m) => [
          ...m,
          {
            id: `err-${Date.now()}`,
            role: "SYSTEM",
            content:
              typeof data.error === "string"
                ? `The story stumbles: ${data.error}`
                : "The story stumbles. Try again.",
            payload: null,
            createdAt: new Date().toISOString(),
          },
        ]);
      } else {
        const { response } = (await res.json()) as { response: DmResponse };
        onDmResponse(response);
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "Network error";
      setMessages((m) => [
        ...m,
        {
          id: `err-${Date.now()}`,
          role: "SYSTEM",
          content: `The story stumbles: ${message}`,
          payload: null,
          createdAt: new Date().toISOString(),
        },
      ]);
    } finally {
      setBusy(false);
      setInputText("");
    }
  }

  async function onSave() {
    await fetch(`/api/campaigns/${props.campaign.id}/save`, { method: "POST" });
  }

  return (
    <main className="mx-auto max-w-7xl px-4 py-6 grid grid-cols-1 lg:grid-cols-[260px_minmax(0,1fr)_280px] gap-4">
      <aside className="space-y-4">
        <PartySidebar party={props.party} />
        <QuestList quests={props.quests} />
      </aside>

      <section className="flex flex-col gap-4 min-h-[80vh]">
        <header className="rune-card flex items-start justify-between gap-4">
          <div>
            <h1 className="font-display text-2xl text-gold-400">
              {props.campaign.name}
            </h1>
            <p className="text-sm text-parchment-200/80">
              {props.currentLocation?.name ?? "Unknown horizon"} ·{" "}
              <span className="font-mono">{props.campaign.inviteCode}</span> ·{" "}
              {props.campaign.mode}
            </p>
            {scene && (
              <p className="text-xs italic text-parchment-200/60 mt-1">
                {scene.mood} — {scene.environment}
              </p>
            )}
          </div>
          <div className="flex gap-2">
            <button onClick={onSave} className="ghost-btn text-xs">
              Save
            </button>
          </div>
        </header>

        <ChatLog messages={messages} />

        {actions.length > 0 && (
          <ActionButtons
            actions={actions}
            disabled={busy}
            onChoose={(a) => submitAction(`I choose: ${a.label}. ${a.description}`, a.id)}
          />
        )}

        <form
          onSubmit={(e) => {
            e.preventDefault();
            submitAction(inputText);
          }}
          className="rune-card flex gap-3 items-end"
        >
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={
              actions.length === 0
                ? "Describe your opening action..."
                : "Or type a custom action..."
            }
            className="flex-1 bg-ink-900/60 border border-gold-500/30 text-parchment-100 rounded-md px-3 py-2 min-h-[60px] focus:outline-none focus:border-gold-400 scroll-thin"
            disabled={busy}
          />
          <button className="gold-btn h-fit" disabled={busy || !inputText.trim()}>
            {busy ? "..." : "Speak"}
          </button>
        </form>
      </section>

      <aside className="space-y-4">
        <div className="rune-card">
          <h3 className="font-display text-lg text-gold-400">Scene</h3>
          {scene ? (
            <div className="text-sm text-parchment-200/85 mt-2 space-y-1">
              <div>
                <span className="text-gold-400">Where:</span> {scene.location}
              </div>
              <div>
                <span className="text-gold-400">Mood:</span> {scene.mood}
              </div>
              <div>
                <span className="text-gold-400">Air:</span> {scene.environment}
              </div>
            </div>
          ) : (
            <p className="text-sm text-parchment-200/60 mt-2">
              The storyteller waits for a first breath.
            </p>
          )}
        </div>
        {combatActive && (
          <div className="rune-card border-ember-500/40">
            <h3 className="font-display text-lg text-ember-500">Combat</h3>
            <p className="text-sm text-parchment-200/80 mt-2">
              Initiative is rolled. Pick your action — the storyteller resolves
              the round.
            </p>
            <button onClick={() => setCombatActive(false)} className="ghost-btn mt-3 text-xs">
              End combat
            </button>
          </div>
        )}
      </aside>
    </main>
  );
}
